<?php

ob_start();
session_start();

require_once('TCPDF-main/tcpdf.php');

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Natthawat Onimsin');
$pdf->SetTitle('PHPLAB2502');
$pdf->SetSubject('phplab-2502');
$pdf->SetKeywords('phplab-2502');

$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

if (@file_exists(dirname(__FILE__).'/lang/eng.php'))
{
require_once(dirname(__FILE__).'/lang/eng.php');
$pdf->setLanguageArray($l);
}

$pdf->SetFont('dejavusans', '', 10);

$pdf->AddPage();

$html=$_SESSION['print_data'];

$_SESSION['print_data'] = null;

$pdf->writeHTML($html, true, false, true, false, '');

$pdf->lastPage();

$pdf->Output('print.pdf', 'I');

?>