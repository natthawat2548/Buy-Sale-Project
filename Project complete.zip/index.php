<?php

ob_start();
session_start();
require_once("class.connect.php");

if(isset($_SESSION['uid']))
{
	$_SESSION['uid'] = $_SESSION['uid'];
}
	else
{
	$_SESSION['uid'] = 0;
}

if(isset($_REQUEST['option']))
{
	$option = $_REQUEST['option'];
}
else
{
	$option = "home";
}

if(isset($_REQUEST['task']))
{
	$task = $_REQUEST['task'];
}
else
{
	$task = "def";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		PHP - 66505100066-9
	</title>
	<meta http-equiv="Content-Type"	content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
	<link href="https://cdn.datatables.net/v/bs5/jq-3.7.0/jszip-3.10.1/dt-2.3.7/af-2.7.1/b-3.2.6/b-colvis-3.2.6/b-html5-3.2.6/b-print-3.2.6/cr-2.1.2/cc-1.2.0/date-1.6.3/fc-5.0.5/fh-4.0.5/kt-2.12.2/r-3.0.8/rg-1.6.0/rr-1.5.1/sc-2.4.3/sb-1.8.4/sp-2.3.5/sl-3.1.3/sr-1.4.3/datatables.min.css" rel="stylesheet" integrity="sha384-JbyirRDAdIEUvVowwyhUPk6l2F37ZNJiRF8dtnLFk1okrZvQHCJEmaaE0L4LhxNW" crossorigin="anonymous">
</head>
<body>
	<?php 
		require_once('class.menu.php');
	?>
	<div class='container'>
		<div class='row'>
			<div class='col-12'>
				<?php 
					require_once('class.'.$option.'.php');
					$class = new $option();
					$class->$task();
				?>
			</div>
		</div>
	</div>
</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.min.js" integrity="sha384-G/EV+4j2dNv+tEPo3++6LCgdCROaejBqfUeNjuKAiuXbjrxilcCdDz6ZAVfHWe1Y" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js" integrity="sha384-VFQrHzqBh5qiJIU0uGU5CIW3+OWpdGGJM9LBnGbuIH2mkICcFZ7lPd/AAtI7SNf7" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js" integrity="sha384-/RlQG9uf0M2vcTw3CX7fbqgbj/h8wKxw7C3zu9/GxcBPRKOEcESxaxufwRXqzq6n" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/v/bs5/jq-3.7.0/jszip-3.10.1/dt-2.3.7/af-2.7.1/b-3.2.6/b-colvis-3.2.6/b-html5-3.2.6/b-print-3.2.6/cr-2.1.2/cc-1.2.0/date-1.6.3/fc-5.0.5/fh-4.0.5/kt-2.12.2/r-3.0.8/rg-1.6.0/rr-1.5.1/sc-2.4.3/sb-1.8.4/sp-2.3.5/sl-3.1.3/sr-1.4.3/datatables.min.js" integrity="sha384-J9wMaVZNvW7912H0GMUH8ZqJCgq2T1VogctcYdXAtr2y1EMQCTFIri/KA84Hsq4S" crossorigin="anonymous"></script>
<script language="javascript">
	new DataTable('#datatables');
</script>
</html>