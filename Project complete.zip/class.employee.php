<?php

class employee
{

	function def()
	{
		?>
		<h2>Employee Management</h2>
				 <button class='btn btn-primary' onclick='window.open("index.php?option=employee&task=edit&id=0&ro=0","_self")'>
				 Add
			    </button>
				<input class="btn btn-success" type ="button" value ="Print" onclick="window.open('index.php?option=employee&task=printed','_blank','toolbar=no,status=no,location=no,menubar=no')" />
		<table id='datatables' class='table table-bordered table-striped'>
			<thead>
				<tr>
					<th class='text-center'>
						ID
					</th>
					<th class='text-center'>
						Name
					</th>
					<th class='text-center'>
						Sirname
					</th>
					<th class='text-center'>
						Salary
					</th>
					<th class='text-center'>
						Status
					</th>
					<th class='text-center'>
						Action
					</th>
				</tr>
			</thead>
			<tbody>
			<?php
				$conn = new connect();
				$sql = "select * from `employee`";
				$res = $conn->query($sql);
				$a = 1;
				while ($cdr = $res->fetch())
				{
					echo "<tr>";
					echo "<td class='text-center'>";
					echo $a;
					echo "</td>";
					echo "<td>";
					echo $cdr['name'];
					echo "</td>";
					echo "<td>";
					echo $cdr['sirname'];
					echo "</td>";
					echo "<td>";
					echo $cdr['salary'];
					echo "</td>";
					echo "<td class='text-center'>";
					if ($cdr['status'] == 1)
					{
						echo "Enable";
						$txt = "Disable";
						$bst = "btn-danger";
						$val = 0;
					}
					else
					{
						echo "Disable";
						$txt = "Enable";
						$bst = "btn-success";
						$val = 1;
					}
					echo "</td>";
					echo "<td class='text-center'>";
					echo "<button class='btn btn-warning' onclick='window.open(\"index.php?option=employee&task=edit&id=".$cdr['id']."&ro=0\",\"_self\")'>";
					echo "Edit";
					echo "</button>";
					echo "<button class='btn btn-info' onclick='window.open(\"index.php?option=employee&task=edit&id=".$cdr['id']."&ro=1\",\"_self\")'>";
					echo "Info";
					echo "</button>";
					echo "<button class='btn $bst' onclick='window.open(\"index.php?option=employee&task=del&id=".$cdr['id']."&val=".$val."\",\"_self\")'>";
					echo $txt;
					echo "</button>";
					echo "</td>";
					echo "</tr>";
					$a++;
				}
			?>
			</tbody>
		</table>
		<?php
	}

	function del()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$val = $_REQUEST['val'];
		$sql = "update `employee` set `status` = '".$val."' where `id` = '".$id."'";
		$res = $conn->query($sql);
		$conn->savelog($_SESSION['uid'],"En/Dis Employee",$sql);
		header("location:index.php?option=employee&task=def");
	}

	function edit()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$ro = $_REQUEST['ro'];
		$rs = "";
		if ($id == 0)
		{
			$head = "Add";
			$name = "";
			$sirname = "";
			$salary = "";
			
		}
		else
		{
			$head = "Edit";
			$sql = "select * from `employee` where `id` = '".$id."'";
			$res = $conn->query($sql);
			while ($cdr = $res->fetch())
			{
				$name = $cdr['name'];
				$sirname = $cdr['sirname'];
				$salary = $cdr['salary'];
			}
		}
		if ($ro == 1)
		{
			$rs = "readonly='true'";
			$head = "Info";
		}
		?>
		<form action='index.php' method='post'>
		<table class='table table-bordered'>
			<tr>
				<td class='text-center' colspan='2'>
					<?php echo $head;?> Employee
				</td>
			</tr>
			<tr>
				<td>
					Name
				</td>
				<td>
					<input name='name' value='<?php echo $name;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td>
					Sirname
				</td>
				<td>
					<input name='sirname' value='<?php echo $sirname;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td>
					Salary
				</td>
				<td>
					<input name='salary' value='<?php echo $salary;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td class='text-center' colspan='2'>
				<?php
					if($ro==0)
					{
					?>
					<input class='btn btn-success' type = 'submit' value='Save' />
					<?php
						}
					?>
					<input class='btn btn-secondary' type = 'button' value ='Back' onclick='window.open("index.php?option=employee&task=def","_self")'/>
					<input type='hidden' name='option' value='employee' />
					<input type='hidden' name='task' value='save' />
					<input type='hidden' name='id' value='<?php echo $id;?>' />
				</td>
			</tr>
		</table>
		</form>
		<?php
	}
		
		function save()
		{
			$conn = new connect();
			$id=$_REQUEST['id'];
			$name=$_REQUEST['name'];
			$sirname=$_REQUEST['sirname'];
			$salary=$_REQUEST['salary'];
			if($id==0)
			{
				$sql = "insert into`employee` set `name` ='".$name."',`sirname` ='".$sirname."',`salary` ='".$salary."'";
			}
			else
			{
				$sql = "update `employee` set `name` ='".$name."',`sirname` ='".$sirname."',`salary` ='".$salary."' where `id`='".$id."'";
			}
		$res = $conn->query($sql);
		$conn->savelog($_SESSION['uid'],"Save Employee",$sql);
		header("location:index.php?option=employee&task=def");
	
		}

				 function printed()
 {
  $conn = new connect();
  $html = '
  <h2>Employee</h2>
    <table border="1" cellpadding="5" cellspacing="0" style="width:100%;border-collapse:collapse,">
     <thead style="background-color:#f2f2f2;">
    <tr>
     <th align="center">
      ID
     </th>
     <th align="center">
      Name
     </th>    
     <th align="center">
      Surname
     </th>
	 <th align="center">
      Salary
     </th>    
     <th align="center">
      Status
     </th>
    </tr>
   </thead>
   <tbody>';

  $sql = "select * from `employee`";
  $res = $conn->query($sql);
  $a = 1;
  while ($cdr = $res->fetch())
  {
   $html = $html."<tr>";
   $html = $html.'<td align="center">';
   $html = $html.$a;
   $html = $html."</td>";
   $html = $html."<td>";
   $html = $html.$cdr['name'];
   $html = $html."</td>";
   $html = $html."<td>";
   $html = $html.$cdr['sirname'];
   $html = $html."</td>";
   $html = $html.'<td align="right">';
   $html = $html.number_format($cdr['salary'],2);
   $html = $html."</td>";
   $html = $html."<td>";
   $html = $html.$cdr['status'];
   $html = $html."</td>";
   $html = $html."</tr>";
   $a++;
  }
   $html=$html.'
   </tbody>
  </table>';
  $_SESSION['print_data']=$html;
  header('location:print.php');
 }
}


?>