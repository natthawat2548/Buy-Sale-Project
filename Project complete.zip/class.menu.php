<nav class="navbar navbar-expand-lg navbar-dark bg-danger" class="navbar navbar-expand">
 <div class="container-fluid">
  <a class="navbar-brand" href="#">PHP-665051000669</a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
   <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
   <ul class="navbar-nav me-auto mb-2 mb-lg-0">
    <li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php">Home</a>
    </li>
	 <?php
		if ($_SESSION['uid'] <> 0)
		{
	 ?>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=users&task=edit&id=0&ro=0">User</a>
	 </li>
	 <li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=stock&task=def">Stock</a>
    </li>
	  <li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=product&task=def">Product</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=customer&task=def">Customer</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=supplier&task=def">Supplier</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=employee&task=def">Employee</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=product&task=def">Product</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=buy&task=def">Buy</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=stock&task=checkstock">Check Stock</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=sale&task=def">Sale</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=logs&task=def">Logs</a>
    </li>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=logs&task=logout">LogOut</a>
    </li>
	<?php
		}
		 else
		 {
	?>
	<li class="nav-item">
     <a class="nav-link active" aria-current="page" href="index.php?option=logs&task=login_form">Login</a>
    </li>
	<?php
		 }	
	?>

   </ul>
  </div>
 </div>
</nav>
