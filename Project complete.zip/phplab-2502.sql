-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2026 at 04:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phplab-2502`
--

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE `buy` (
  `id` int(5) NOT NULL,
  `supplier_id` int(5) NOT NULL,
  `dating` varchar(20) NOT NULL,
  `uid` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`id`, `supplier_id`, `dating`, `uid`, `status`) VALUES
(1, 1, '1770353051', 1, 1),
(2, 1, '1770352979', 1, 1),
(3, 1, '1770352459', 1, 1),
(4, 1, '1770352463', 1, 1),
(5, 1, '1770352502', 1, 1),
(6, 4, '1770352520', 1, 1),
(7, 5, '1770352529', 1, 1),
(8, 3, '1770352620', 1, 1),
(9, 1, '1770352625', 1, 1),
(10, 1, '1770352947', 1, 1),
(11, 1, '1770354155', 1, 1),
(12, 2, '1770354170', 1, 1),
(13, 2, '1770354288', 1, 1),
(14, 1, '1770354337', 1, 1),
(15, 1, '1770354579', 1, 1),
(16, 2, '1770354600', 1, 1),
(17, 4, '1770354900', 1, 1),
(18, 1, '1770374969', 1, 1),
(19, 1, '1771578661', 1, 1),
(20, 1, '1771578695', 1, 1),
(21, 2, '1771579510', 1, 1),
(22, 2, '1771579536', 1, 1),
(23, 7, '1771579558', 1, 1),
(24, 8, '1771579608', 1, 1),
(25, 1, '1771579674', 1, 1),
(26, 1, '1771579701', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `buy_detail`
--

CREATE TABLE `buy_detail` (
  `id` int(5) NOT NULL,
  `buy_id` int(5) NOT NULL,
  `stock_id` int(5) NOT NULL,
  `num` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `buy_detail`
--

INSERT INTO `buy_detail` (`id`, `buy_id`, `stock_id`, `num`, `status`) VALUES
(1, 1, 1, 1000, 0),
(2, 1, 1, 800, 0),
(3, 2, 2, 200, 0),
(4, 2, 2, 200, 0),
(5, 3, 1, 1000, 1),
(6, 4, 2, 10000, 1),
(7, 6, 1, 10, 1),
(8, 7, 1, 1000, 1),
(9, 7, 2, 1000, 1),
(10, 8, 1, 100, 1),
(11, 8, 2, 100, 1),
(12, 8, 3, 100, 1),
(13, 9, 9, 100, 1),
(14, 9, 10, 100, 1),
(15, 9, 11, 100, 1),
(16, 10, 1, 1000, 1),
(17, 2, 2, 200, 1),
(18, 1, 1, 800, 1),
(19, 11, 1, 100, 1),
(20, 12, 2, 1000, 1),
(21, 13, 2, 100, 1),
(22, 14, 1, 100, 1),
(23, 15, 1, 100, 1),
(24, 16, 2, 1000, 1),
(25, 17, 1, 100, 1),
(26, 18, 1, 1000, 1),
(27, 18, 2, 40000, 1),
(28, 18, 3, 1000, 1),
(29, 18, 4, 1000, 1),
(30, 19, 1, 100, 1),
(31, 19, 2, 100, 1),
(32, 20, 1, 100, 1),
(33, 21, 3, 100, 1),
(34, 22, 3, 100, 1),
(35, 23, 1, 100, 1),
(36, 24, 1, 100, 1),
(37, 24, 2, 10, 1),
(38, 24, 3, 20, 1),
(39, 24, 4, 20, 1),
(40, 24, 5, 20, 1),
(41, 25, 1, 1, 1),
(42, 26, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `status`) VALUES
(7, 'Ca', 1),
(8, 'Cb', 1),
(9, 'Cc', 1),
(10, 'Cd', 1),
(11, 'Ce', 1),
(12, 'Cf', 1),
(13, 'Cg', 1),
(14, 'Ch', 1),
(15, 'dix', 1),
(16, 'a', 1),
(17, 'Ca', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `sirname` varchar(50) NOT NULL,
  `salary` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `sirname`, `salary`, `status`) VALUES
(5, 'AAAA', 'aaaa', 10000, 1),
(6, 'BBBB', 'bbbb', 20000, 1),
(7, 'CCCC', 'cccc', 30000, 1),
(8, 'ddd', 'ddd', 100000, 1),
(9, 'a', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(5) NOT NULL,
  `action` varchar(50) NOT NULL,
  `detail` varchar(500) NOT NULL,
  `dating` varchar(50) NOT NULL,
  `uid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `action`, `detail`, `dating`, `uid`) VALUES
(1, 'Log out', 'Log out', '1769147190', 2),
(2, 'Log out', 'Log out', '1769147204', 1),
(3, 'Log out', 'Log out', '1769148335', 2),
(4, 'Log in', 'Login pass', '1769148343', 1),
(5, 'Log out', 'Log out', '1769148354', 1),
(6, 'Log in', 'Login error', '1769148362', 0),
(7, 'Log in', 'Login pass', '1769148904', 1),
(8, 'En/Dis Customer', 'update `customer` set `status` = \'0\' where `id` = \'7\'', '1769149012', 1),
(9, 'En/Dis Customer', 'update `customer` set `status` = \'1\' where `id` = \'7\'', '1769149013', 1),
(10, 'Save', 'insert into`customer` set `name` =\'dix\'', '1769149026', 1),
(11, 'En/Dis Customer', 'update `customer` set `status` = \'0\' where `id` = \'7\'', '1769151434', 1),
(12, 'En/Dis Customer', 'update `customer` set `status` = \'1\' where `id` = \'7\'', '1769151435', 1),
(13, 'Save employee', 'insert into`employee` set `name` =\'ddd\',`sirname` =\'ddd\',`salary` =\'100000\'', '1769151444', 1),
(14, 'Save Stock', 'insert into`stock` set `name` =\'a\',`buy` =\'10\',`sale` =\'10\'', '1769151644', 1),
(15, 'En/Dis Stock', 'update `stock` set `status` = \'0\' where `id` = \'1\'', '1769151645', 1),
(16, 'En/Dis Stock', 'update `stock` set `status` = \'1\' where `id` = \'1\'', '1769151646', 1),
(17, 'Save customer', 'insert into`customer` set `name` =\'a\'', '1769151653', 1),
(18, 'En/Dis Customer', 'update `customer` set `status` = \'0\' where `id` = \'7\'', '1769151654', 1),
(19, 'En/Dis Customer', 'update `customer` set `status` = \'1\' where `id` = \'7\'', '1769151655', 1),
(20, 'Save Suppiler', 'insert into`supplier` set `name` =\'a\'', '1769151659', 1),
(21, 'En/Dis Supplier', 'update `supplier` set `status` = \'0\' where `id` = \'1\'', '1769151660', 1),
(22, 'En/Dis Supplier', 'update `supplier` set `status` = \'1\' where `id` = \'1\'', '1769151660', 1),
(23, 'Save Employee', 'insert into`employee` set `name` =\'a\',`sirname` =\'a\',`salary` =\'1\'', '1769151670', 1),
(24, 'Save Location', 'insert into`location` set `name` =\'เชียงราย\',`motto` =\'เหนือสุดในสยาม ชายแดนสามแผ่นดิน ถิ่นวัฒนธรรมล้านนา ล้ำค่าพระธาตุดอยตุง \'', '1769153888', 1),
(25, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769153906', 1),
(26, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769154442', 1),
(27, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1769154443', 1),
(28, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'2\'', '1769154443', 1),
(29, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'2\'', '1769154444', 1),
(30, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'2\'', '1769154444', 1),
(31, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769154445', 1),
(32, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'2\'', '1769154445', 1),
(33, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1769154446', 1),
(34, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'2\'', '1769154446', 1),
(35, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'3\'', '1769154447', 1),
(36, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'3\'', '1769154447', 1),
(37, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'2\'', '1769154448', 1),
(38, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769154515', 1),
(39, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1769154516', 1),
(40, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769154517', 1),
(41, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1769154518', 1),
(42, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769154533', 1),
(43, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1769154534', 1),
(44, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769154534', 1),
(45, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'2\'', '1769154535', 1),
(46, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'2\'', '1769154536', 1),
(47, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'3\'', '1769154537', 1),
(48, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'3\'', '1769154538', 1),
(49, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1769154539', 1),
(50, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769154540', 1),
(51, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'5\'', '1769154541', 1),
(52, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'5\'', '1769154541', 1),
(53, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1769154542', 1),
(54, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1769154648', 1),
(55, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1769154648', 1),
(56, 'Log in', 'Login pass', '1769739230', 1),
(57, 'En/Dis Stock', 'update `stock` set `status` = \'0\' where `id` = \'1\'', '1769750675', 1),
(58, 'En/Dis Stock', 'update `stock` set `status` = \'1\' where `id` = \'1\'', '1769750676', 1),
(59, 'En/Dis Stock', 'update `stock` set `status` = \'0\' where `id` = \'1\'', '1769750676', 1),
(60, 'En/Dis Stock', 'update `stock` set `status` = \'1\' where `id` = \'1\'', '1769750699', 1),
(61, 'En/Dis Stock', 'update `stock` set `status` = \'0\' where `id` = \'1\'', '1769750701', 1),
(62, 'En/Dis Stock', 'update `stock` set `status` = \'1\' where `id` = \'1\'', '1769750703', 1),
(63, 'En/Dis Customer', 'update `customer` set `status` = \'0\' where `id` = \'7\'', '1769751233', 1),
(64, 'En/Dis Customer', 'update `customer` set `status` = \'1\' where `id` = \'7\'', '1769751233', 1),
(65, 'En/Dis Buy', 'update `buy` set `status` = \'0\' where `id` = \'1\'', '1769761691', 1),
(66, 'En/Dis Buy', 'update `buy` set `status` = \'1\' where `id` = \'1\'', '1769761691', 1),
(67, 'En/Dis Buy', 'update `buy` set `status` = \'0\' where `id` = \'1\'', '1769761692', 1),
(68, 'En/Dis Buy', 'update `buy` set `status` = \'1\' where `id` = \'1\'', '1769761692', 1),
(69, 'En/Dis Buy', 'update `buy` set `status` = \'0\' where `id` = \'2\'', '1769761693', 1),
(70, 'En/Dis Buy', 'update `buy` set `status` = \'1\' where `id` = \'2\'', '1769761693', 1),
(71, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769761922\', `uid` = \'1\'', '1769761922', 1),
(72, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769761926\', `uid` = \'1\'', '1769761926', 1),
(73, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769761927\', `uid` = \'1\'where `id` = \'1\'', '1769761927', 1),
(74, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763087\', `uid` = \'1\'', '1769763087', 1),
(75, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763089\', `uid` = \'1\'', '1769763089', 1),
(76, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763090\', `uid` = \'1\'', '1769763090', 1),
(77, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763258\', `uid` = \'1\'', '1769763258', 1),
(78, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763294\', `uid` = \'1\'', '1769763294', 1),
(79, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763300\', `uid` = \'1\'', '1769763300', 1),
(80, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763307\', `uid` = \'1\'', '1769763307', 1),
(81, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763570\', `uid` = \'1\'', '1769763570', 1),
(82, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763573\', `uid` = \'1\'', '1769763573', 1),
(83, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763578\', `uid` = \'1\'', '1769763578', 1),
(84, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763581\', `uid` = \'1\'', '1769763581', 1),
(85, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763644\', `uid` = \'1\'', '1769763644', 1),
(86, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763649\', `uid` = \'1\'', '1769763649', 1),
(87, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769763652\', `uid` = \'1\'', '1769763653', 1),
(88, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763660\', `uid` = \'1\'', '1769763660', 1),
(89, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763792\', `uid` = \'1\'', '1769763792', 1),
(90, 'En/Dis sale', 'update `sale` set `status` = \'0\' where `id` = \'0\'', '1769763793', 1),
(91, 'En/Dis sale', 'update `sale` set `status` = \'1\' where `id` = \'0\'', '1769763794', 1),
(92, 'En/Dis sale', 'update `sale` set `status` = \'0\' where `id` = \'0\'', '1769763795', 1),
(93, 'En/Dis sale', 'update `sale` set `status` = \'1\' where `id` = \'0\'', '1769763796', 1),
(94, 'Save sale', 'insert into `sale` set `supplier_id` = \'4\', `dating` =\'1769763803\', `uid` = \'1\'', '1769763803', 1),
(95, 'En/Dis sale', 'update `sale` set `status` = \'0\' where `id` = \'0\'', '1769763804', 1),
(96, 'En/Dis sale', 'update `sale` set `status` = \'1\' where `id` = \'0\'', '1769763805', 1),
(97, 'En/Dis Buy', 'update `buy` set `status` = \'0\' where `id` = \'1\'', '1769763814', 1),
(98, 'En/Dis Buy', 'update `buy` set `status` = \'1\' where `id` = \'1\'', '1769763814', 1),
(99, 'En/Dis Buy', 'update `buy` set `status` = \'0\' where `id` = \'2\'', '1769763814', 1),
(100, 'En/Dis Buy', 'update `buy` set `status` = \'1\' where `id` = \'2\'', '1769763815', 1),
(101, 'En/Dis Buy', 'update `buy` set `status` = \'0\' where `id` = \'3\'', '1769763815', 1),
(102, 'En/Dis Buy', 'update `buy` set `status` = \'1\' where `id` = \'3\'', '1769763816', 1),
(103, 'En/Dis sale', 'update `sale` set `status` = \'0\' where `id` = \'0\'', '1769763860', 1),
(104, 'En/Dis sale', 'update `sale` set `status` = \'1\' where `id` = \'0\'', '1769763861', 1),
(105, 'En/Dis sale', 'update `sale` set `status` = \'0\' where `id` = \'0\'', '1769763861', 1),
(106, 'En/Dis sale', 'update `sale` set `status` = \'1\' where `id` = \'0\'', '1769763862', 1),
(107, 'En/Dis sale', 'update `sale` set `status` = \'0\' where `id` = \'0\'', '1769763864', 1),
(108, 'En/Dis sale', 'update `sale` set `status` = \'1\' where `id` = \'0\'', '1769763865', 1),
(109, 'En/Dis sale', 'update `sale` set `status` = \'0\' where `id` = \'1\'', '1769763919', 1),
(110, 'En/Dis sale', 'update `sale` set `status` = \'0\' where `id` = \'2\'', '1769763920', 1),
(111, 'En/Dis sale', 'update `sale` set `status` = \'1\' where `id` = \'1\'', '1769763920', 1),
(112, 'En/Dis sale', 'update `sale` set `status` = \'1\' where `id` = \'2\'', '1769763921', 1),
(113, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763926\', `uid` = \'1\'', '1769763926', 1),
(114, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769763935\', `uid` = \'1\'', '1769763935', 1),
(115, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769764005\', `uid` = \'1\'', '1769764005', 1),
(116, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769764119\', `uid` = \'1\'where `id` = \'1\'', '1769764119', 1),
(117, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769764282\', `uid` = \'1\'', '1769764282', 1),
(118, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769764694\', `uid` = \'1\'', '1769764694', 1),
(119, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769764704\', `uid` = \'1\'', '1769764704', 1),
(120, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769765161\', `uid` = \'1\'', '1769765161', 1),
(121, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769765169\', `uid` = \'1\'', '1769765169', 1),
(122, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769765177\', `uid` = \'1\'', '1769765177', 1),
(123, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769765195\', `uid` = \'1\'', '1769765195', 1),
(124, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769765241\', `uid` = \'1\'', '1769765241', 1),
(125, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769765248\', `uid` = \'1\'', '1769765248', 1),
(126, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769766094\', `uid` = \'1\'', '1769766094', 1),
(127, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769766110\', `uid` = \'1\'', '1769766110', 1),
(128, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769766120\', `uid` = \'1\'', '1769766120', 1),
(129, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769766125\', `uid` = \'1\'', '1769766125', 1),
(130, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769766917\', `uid` = \'1\'', '1769766917', 1),
(131, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769766925\', `uid` = \'1\'', '1769766925', 1),
(132, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769767035\', `uid` = \'1\'', '1769767035', 1),
(133, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769767040\', `uid` = \'1\'', '1769767040', 1),
(134, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769767229\', `uid` = \'1\'', '1769767229', 1),
(135, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769767239\', `uid` = \'1\'', '1769767239', 1),
(136, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769767253\', `uid` = \'1\'', '1769767253', 1),
(137, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769767292\', `uid` = \'1\'', '1769767292', 1),
(138, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769767299\', `uid` = \'1\'', '1769767299', 1),
(139, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769767421\', `uid` = \'1\'', '1769767421', 1),
(140, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769767439\', `uid` = \'1\'', '1769767439', 1),
(141, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769767810\', `uid` = \'1\'', '1769767810', 1),
(142, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769767817\', `uid` = \'1\'', '1769767817', 1),
(143, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769767978\', `uid` = \'1\'', '1769767978', 1),
(144, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769767987\', `uid` = \'1\'', '1769767987', 1),
(145, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769767993\', `uid` = \'1\'', '1769767993', 1),
(146, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769767999\', `uid` = \'1\'', '1769767999', 1),
(147, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769134\', `uid` = \'1\'', '1769769134', 1),
(148, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769769138\', `uid` = \'1\'', '1769769138', 1),
(149, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769769156\', `uid` = \'1\'where `id` = \'1\'', '1769769156', 1),
(150, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769769161\', `uid` = \'1\'where `id` = \'1\'', '1769769161', 1),
(151, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769769372\', `uid` = \'1\'', '1769769372', 1),
(152, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769769377\', `uid` = \'1\'where `id` = \'1\'', '1769769377', 1),
(153, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769385\', `uid` = \'1\'', '1769769385', 1),
(154, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769392\', `uid` = \'1\'where `id` = \'1\'', '1769769393', 1),
(155, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769397\', `uid` = \'1\'where `id` = \'1\'', '1769769397', 1),
(156, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769406\', `uid` = \'1\'where `id` = \'1\'', '1769769406', 1),
(157, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769411\', `uid` = \'1\'where `id` = \'1\'', '1769769411', 1),
(158, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769416\', `uid` = \'1\'', '1769769416', 1),
(159, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769424\', `uid` = \'1\'where `id` = \'1\'', '1769769424', 1),
(160, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769436\', `uid` = \'1\'', '1769769436', 1),
(161, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769446\', `uid` = \'1\'where `id` = \'1\'', '1769769446', 1),
(162, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769455\', `uid` = \'1\'where `id` = \'1\'', '1769769455', 1),
(163, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769535\', `uid` = \'1\'', '1769769535', 1),
(164, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769545\', `uid` = \'1\'where `id` = \'1\'', '1769769545', 1),
(165, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769591\', `uid` = \'1\'', '1769769591', 1),
(166, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769599\', `uid` = \'1\'where `id` = \'1\'', '1769769599', 1),
(167, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769621\', `uid` = \'1\'', '1769769621', 1),
(168, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769631\', `uid` = \'1\'where `id` = \'1\'', '1769769631', 1),
(169, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769769645\', `uid` = \'1\'', '1769769645', 1),
(170, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769669\', `uid` = \'1\'where `id` = \'1\'', '1769769669', 1),
(171, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769689\', `uid` = \'1\'', '1769769689', 1),
(172, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769722\', `uid` = \'1\'', '1769769722', 1),
(173, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769748\', `uid` = \'1\'where `id` = \'1\'', '1769769748', 1),
(174, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769780\', `uid` = \'1\'where `id` = \'1\'', '1769769780', 1),
(175, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769870\', `uid` = \'1\'', '1769769870', 1),
(176, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769769941\', `uid` = \'1\'', '1769769941', 1),
(177, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769769957\', `uid` = \'1\'where `id` = \'1\'', '1769769958', 1),
(178, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769770007\', `uid` = \'1\'', '1769770007', 1),
(179, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769770026\', `uid` = \'1\'where `id` = \'1\'', '1769770026', 1),
(180, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769770039\', `uid` = \'1\'', '1769770039', 1),
(181, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769770074\', `uid` = \'1\'', '1769770074', 1),
(182, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769770087\', `uid` = \'1\'where `id` = \'1\'', '1769770087', 1),
(183, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769770090\', `uid` = \'1\'where `id` = \'1\'', '1769770090', 1),
(184, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769770104\', `uid` = \'1\'', '1769770104', 1),
(185, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769770111\', `uid` = \'1\'where `id` = \'1\'', '1769770111', 1),
(186, 'Save sale', 'update `sale` set `supplier_id` = \'1\', `dating` =\'1769770114\', `uid` = \'1\'where `id` = \'1\'', '1769770114', 1),
(187, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769770124\', `uid` = \'1\'', '1769770124', 1),
(188, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769770204\', `uid` = \'1\'', '1769770204', 1),
(189, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769770214\', `uid` = \'1\'where `id` = \'1\'', '1769770214', 1),
(190, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1769770223\', `uid` = \'1\'', '1769770223', 1),
(191, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1769770234\', `uid` = \'1\'where `id` = \'2\'', '1769770234', 1),
(192, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1769770353\', `uid` = \'1\'', '1769770353', 1),
(193, 'Log in', 'Login pass', '1770344632', 1),
(194, 'Save customer', 'update `customer` set `name` =\'Ca\' where `id`=\'7\'', '1770348907', 1),
(195, 'En/Dis Customer', 'update `customer` set `status` = \'0\' where `id` = \'7\'', '1770348909', 1),
(196, 'En/Dis Customer', 'update `customer` set `status` = \'1\' where `id` = \'7\'', '1770348909', 1),
(197, 'En/Dis Customer', 'update `customer` set `status` = \'0\' where `id` = \'7\'', '1770348910', 1),
(198, 'En/Dis Customer', 'update `customer` set `status` = \'1\' where `id` = \'7\'', '1770348910', 1),
(199, 'En/Dis Customer', 'update `customer` set `status` = \'0\' where `id` = \'7\'', '1770348910', 1),
(200, 'En/Dis Customer', 'update `customer` set `status` = \'1\' where `id` = \'7\'', '1770348945', 1),
(201, 'Save customer', 'insert into`customer` set `name` =\'Ca\'', '1770351390', 1),
(202, 'Save sale', 'insert into `sale` set `supplier_id` = \'1\', `dating` =\'1770352449\', `uid` = \'1\'', '1770352449', 1),
(203, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1770352459\', `uid` = \'1\'', '1770352459', 1),
(204, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1770352463\', `uid` = \'1\'', '1770352463', 1),
(205, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1770352502\', `uid` = \'1\'', '1770352502', 1),
(206, 'Save Buy', 'insert into `buy` set `supplier_id` = \'4\', `dating` =\'1770352520\', `uid` = \'1\'', '1770352520', 1),
(207, 'Save Buy', 'insert into `buy` set `supplier_id` = \'5\', `dating` =\'1770352529\', `uid` = \'1\'', '1770352529', 1),
(208, 'Save product', 'insert into`product` set `name` =\'Product N\',`buy` =\'100\',`sale` =\'20\'', '1770352583', 1),
(209, 'Save Buy', 'insert into `buy` set `supplier_id` = \'3\', `dating` =\'1770352620\', `uid` = \'1\'', '1770352620', 1),
(210, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1770352625\', `uid` = \'1\'', '1770352625', 1),
(211, 'Save sale', 'insert into `sale` set `customer_id` = \'\', `dating` =\'1770352811\', `uid` = \'1\'', '1770352811', 1),
(212, 'Save sale', 'insert into `sale` set `customer_id` = \'\', `dating` =\'1770352875\', `uid` = \'1\'', '1770352875', 1),
(213, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770352919\', `uid` = \'1\'', '1770352919', 1),
(214, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770352936\', `uid` = \'1\'', '1770352936', 1),
(215, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1770352947\', `uid` = \'1\'', '1770352947', 1),
(216, 'Save sale', 'insert into `sale` set `customer_id` = \'8\', `dating` =\'1770352965\', `uid` = \'1\'', '1770352965', 1),
(217, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1770352979\', `uid` = \'1\'where `id` = \'2\'', '1770352979', 1),
(218, 'Save Buy', 'update `buy` set `supplier_id` = \'1\', `dating` =\'1770353051\', `uid` = \'1\'where `id` = \'1\'', '1770353051', 1),
(219, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770354127\', `uid` = \'1\'', '1770354127', 1),
(220, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770354136\', `uid` = \'1\'', '1770354136', 1),
(221, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1770354155\', `uid` = \'1\'', '1770354155', 1),
(222, 'Save Buy', 'insert into `buy` set `supplier_id` = \'2\', `dating` =\'1770354170\', `uid` = \'1\'', '1770354170', 1),
(223, 'Save Buy', 'insert into `buy` set `supplier_id` = \'2\', `dating` =\'1770354288\', `uid` = \'1\'', '1770354288', 1),
(224, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770354305\', `uid` = \'1\'', '1770354305', 1),
(225, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1770354337\', `uid` = \'1\'', '1770354337', 1),
(226, 'Save Buy', 'insert into `buy` set `supplier_id` = \'1\', `dating` =\'1770354579\', `uid` = \'1\'', '1770354579', 1),
(227, 'Save Buy', 'insert into `buy` set `supplier_id` = \'2\', `dating` =\'1770354600\', `uid` = \'1\'', '1770354600', 1),
(228, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770354717\', `uid` = \'1\'', '1770354717', 1),
(229, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770354729\', `uid` = \'1\'', '1770354729', 1),
(230, 'Save sale', 'insert into `sale` set `customer_id` = \'8\', `dating` =\'1770354743\', `uid` = \'1\'', '1770354743', 1),
(231, 'Save sale', 'insert into `sale` set `customer_id` = \'8\', `dating` =\'1770354753\', `uid` = \'1\'', '1770354753', 1),
(232, 'Save sale', 'insert into `sale` set `customer_id` = \'11\', `dating` =\'1770354783\', `uid` = \'1\'', '1770354783', 1),
(233, 'Save Buy', 'insert into `buy` set `supplier_id` = \'4\', `dating` =\'1770354900\', `uid` = \'1\'', '1770354900', 1),
(234, 'Log out', 'Log out', '1770358944', 1),
(235, 'Log in', 'Login pass', '1770358952', 1),
(236, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770366644\', `uid` = \'1\'', '1770366644', 1),
(237, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770366660\', `uid` = \'1\'', '1770366660', 1),
(238, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770366824\', `uid` = \'1\'', '1770366824', 1),
(239, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770366885\', `uid` = \'1\'', '1770366885', 1),
(240, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770368949\', `uid` = \'1\'', '1770368949', 1),
(241, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770368963\', `uid` = \'1\'', '1770368963', 1),
(242, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770368992\', `uid` = \'1\'', '1770368992', 1),
(243, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369043\', `uid` = \'1\'', '1770369043', 1),
(244, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369096\', `uid` = \'1\'', '1770369096', 1),
(245, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369322\', `uid` = \'1\'', '1770369323', 1),
(246, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369437\', `uid` = \'1\'', '1770369437', 1),
(247, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770369443\', `uid` = \'1\'where `id` = \'\'', '1770369443', 1),
(248, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369615\', `uid` = \'1\'', '1770369615', 1),
(249, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369649\', `uid` = \'1\'', '1770369649', 1),
(250, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369735\', `uid` = \'1\'', '1770369735', 1),
(251, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369805\', `uid` = \'1\'', '1770369805', 1),
(252, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369844\', `uid` = \'1\'', '1770369844', 1),
(253, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770369871\', `uid` = \'1\'', '1770369871', 1),
(254, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770370273\', `uid` = \'1\'', '1770370273', 1),
(255, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770370279\', `uid` = \'1\'where `id` = \'5\'', '1770370279', 1),
(256, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770370430\', `uid` = \'1\'where `id` = \'5\'', '1770370430', 1),
(257, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770370573\', `uid` = \'1\'', '1770370573', 1),
(258, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770370599\', `uid` = \'1\'', '1770370599', 1),
(259, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770370728\', `uid` = \'1\'', '1770370728', 1),
(260, 'Save sale', 'insert into `sale` set `customer_id` = \'8\', `dating` =\'1770370986\', `uid` = \'1\'', '1770370986', 1),
(261, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770371009\', `uid` = \'1\'', '1770371009', 1),
(262, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770371210\', `uid` = \'1\'', '1770371210', 1),
(263, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770371504\', `uid` = \'1\'', '1770371505', 1),
(264, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770371557\', `uid` = \'1\'', '1770371557', 1),
(265, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770371771\', `uid` = \'1\'', '1770371771', 1),
(266, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372063\', `uid` = \'1\'where `id` = \'5\'', '1770372063', 1),
(267, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770372165\', `uid` = \'1\'', '1770372165', 1),
(268, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770372172\', `uid` = \'1\'', '1770372172', 1),
(269, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372188\', `uid` = \'1\'where `id` = \'5\'', '1770372188', 1),
(270, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372191\', `uid` = \'1\'where `id` = \'5\'', '1770372191', 1),
(271, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372218\', `uid` = \'1\'where `id` = \'5\'', '1770372218', 1),
(272, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372269\', `uid` = \'1\'where `id` = \'5\'', '1770372269', 1),
(273, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372295\', `uid` = \'1\'where `id` = \'5\'', '1770372295', 1),
(274, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372411\', `uid` = \'1\'where `id` = \'5\'', '1770372411', 1),
(275, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770372414\', `uid` = \'1\'', '1770372414', 1),
(276, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372437\', `uid` = \'1\'where `id` = \'5\'', '1770372437', 1),
(277, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372442\', `uid` = \'1\'where `id` = \'5\'', '1770372442', 1),
(278, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372460\', `uid` = \'1\'where `id` = \'5\'', '1770372460', 1),
(279, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372463\', `uid` = \'1\'where `id` = \'5\'', '1770372463', 1),
(280, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372483\', `uid` = \'1\'where `id` = \'5\'', '1770372483', 1),
(281, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372485\', `uid` = \'1\'where `id` = \'5\'', '1770372485', 1),
(282, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372590\', `uid` = \'1\'where `id` = \'5\'', '1770372590', 1),
(283, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372593\', `uid` = \'1\'where `id` = \'5\'', '1770372593', 1),
(284, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770372690\', `uid` = \'1\'', '1770372690', 1),
(285, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770372695\', `uid` = \'1\'', '1770372695', 1),
(286, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372830\', `uid` = \'1\'where `id` = \'5\'', '1770372830', 1),
(287, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372835\', `uid` = \'1\'where `id` = \'5\'', '1770372835', 1),
(288, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770372966\', `uid` = \'1\'where `id` = \'5\'', '1770372966', 1),
(289, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770373377\', `uid` = \'1\'where `id` = \'5\'', '1770373377', 1),
(290, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770373387\', `uid` = \'1\'', '1770373387', 1),
(291, 'Save sale', 'update `sale` set `customer_id` = \'7\', `dating` =\'1770373395\', `uid` = \'1\'where `id` = \'5\'', '1770373395', 1),
(292, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770374097\', `uid` = \'1\'', '1770374097', 1),
(293, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770374343\', `uid` = \'1\'', '1770374343', 1),
(294, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770374494\', `uid` = \'1\'', '1770374494', 1),
(295, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770374855\', `uid` = \'1\'', '1770374855', 1),
(296, 'Save Buy', 'insert into buy set supplier_id = \'1\', dating =\'1770374969\', uid = \'1\'', '1770374969', 1),
(297, 'Save sale', 'insert into `sale` set `customer_id` = \'7\', `dating` =\'1770374996\', `uid` = \'1\'', '1770374996', 1),
(298, 'Log in', 'Login pass', '1770948494', 1),
(299, 'En/Dis Stock', 'update `stock` set `status` = \'0\' where `id` = \'1\'', '1770953442', 1),
(300, 'En/Dis Stock', 'update `stock` set `status` = \'1\' where `id` = \'1\'', '1770953442', 1),
(301, 'Log out', 'Log out', '1770959478', 1),
(302, 'Log in', 'Login pass', '1770959487', 1),
(303, 'Save User', 'insert into`users` set `login` =\'\',`name` =\'\',`pass` =\'\',`u_type` =\'2\'', '1770961075', 1),
(304, 'Save Stock', 'insert into`stock` set name =\'sasa\',`buy` =\'100\',`sale` =\'2000\'', '1770962393', 1),
(305, 'Log out', 'Log out', '1770962410', 1),
(306, 'Log in', 'Login pass', '1770962415', 1),
(307, 'En/Dis location', 'update `location` set `status` = \'1\' where `id` = \'1\'', '1770962700', 1),
(308, 'En/Dis location', 'update `location` set `status` = \'0\' where `id` = \'1\'', '1770962706', 1),
(309, 'Log in', 'Login pass', '1771560087', 1),
(310, 'Log out', 'Log out', '1771560101', 1),
(311, 'Log in', 'Login pass', '1771560107', 1),
(312, 'Save Buy', 'insert into buy set supplier_id = \'1\', dating =\'1771578661\', uid = \'1\'', '1771578661', 1),
(313, 'Save Buy', 'insert into buy set supplier_id = \'1\', dating =\'1771578695\', uid = \'1\'', '1771578695', 1),
(314, 'Save Buy', 'insert into buy set supplier_id = \'2\', dating =\'1771579510\', uid = \'1\'', '1771579510', 1),
(315, 'Save Buy', 'insert into buy set supplier_id = \'2\', dating =\'1771579536\', uid = \'1\'', '1771579536', 1),
(316, 'Save Buy', 'insert into buy set supplier_id = \'7\', dating =\'1771579558\', uid = \'1\'', '1771579558', 1),
(317, 'Save Buy', 'insert into buy set supplier_id = \'8\', dating =\'1771579608\', uid = \'1\'', '1771579608', 1),
(318, 'Save Buy', 'insert into buy set supplier_id = \'1\', dating =\'1771579674\', uid = \'1\'', '1771579674', 1),
(319, 'Save Buy', 'insert into buy set supplier_id = \'1\', dating =\'1771579701\', uid = \'1\'', '1771579701', 1),
(320, 'Save sale', 'insert into `sale` set `customer_id` = \'14\', `dating` =\'1771579965\', `uid` = \'1\'', '1771579965', 1),
(321, 'Save sale', 'insert into `sale` set `customer_id` = \'13\', `dating` =\'1771579994\', `uid` = \'1\'', '1771579994', 1),
(322, 'Save sale', 'insert into `sale` set `customer_id` = \'11\', `dating` =\'1771580137\', `uid` = \'1\'', '1771580137', 1),
(323, 'Log in', 'Login pass', '1772163221', 1),
(324, 'En/Dis product', 'update `product` set `status` = \'0\' where `id` = \'1\'', '1772163543', 1),
(325, 'En/Dis product', 'update `product` set `status` = \'1\' where `id` = \'1\'', '1772163544', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `buy` int(5) NOT NULL,
  `sale` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `buy`, `sale`, `status`) VALUES
(1, 'Product A', 20, 10, 1),
(2, 'Product B', 15, 20, 1),
(3, 'Product C', 20, 25, 1),
(4, 'Product D', 15, 30, 1),
(5, 'Product E', 25, 30, 1),
(6, 'Product F', 5, 20, 1),
(7, 'Product G', 10, 30, 1),
(8, 'Product H', 15, 25, 1),
(9, 'Product I', 5, 30, 1),
(10, 'Product J', 15, 35, 1),
(11, 'Product K', 15, 40, 1),
(12, 'Product L', 10, 40, 1),
(13, 'Product N', 100, 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE `sale` (
  `id` int(5) NOT NULL,
  `customer_id` int(5) NOT NULL,
  `dating` varchar(20) NOT NULL,
  `uid` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `sale`
--

INSERT INTO `sale` (`id`, `customer_id`, `dating`, `uid`, `status`) VALUES
(1, 0, '1769770353', 1, 1),
(2, 0, '1770352449', 1, 1),
(3, 0, '1770352811', 1, 1),
(4, 0, '1770352875', 1, 1),
(5, 7, '1770373395', 1, 1),
(6, 7, '1770352936', 1, 1),
(7, 8, '1770352965', 1, 1),
(8, 7, '1770354127', 1, 1),
(9, 7, '1770354136', 1, 1),
(10, 7, '1770354305', 1, 1),
(11, 7, '1770354717', 1, 1),
(12, 7, '1770354729', 1, 1),
(13, 8, '1770354743', 1, 1),
(14, 8, '1770354753', 1, 1),
(15, 11, '1770354783', 1, 1),
(16, 7, '1770366644', 1, 1),
(17, 7, '1770366660', 1, 1),
(18, 7, '1770366824', 1, 1),
(19, 7, '1770366885', 1, 1),
(20, 7, '1770368949', 1, 1),
(21, 7, '1770368963', 1, 1),
(22, 7, '1770368992', 1, 1),
(23, 7, '1770369043', 1, 1),
(24, 7, '1770369096', 1, 1),
(25, 7, '1770369322', 1, 1),
(26, 7, '1770369437', 1, 1),
(27, 7, '1770369615', 1, 1),
(28, 7, '1770369649', 1, 1),
(29, 7, '1770369735', 1, 1),
(30, 7, '1770369805', 1, 1),
(31, 7, '1770369844', 1, 1),
(32, 7, '1770369871', 1, 1),
(33, 7, '1770370273', 1, 1),
(34, 7, '1770370573', 1, 1),
(35, 7, '1770370599', 1, 1),
(36, 7, '1770370728', 1, 1),
(37, 8, '1770370986', 1, 1),
(38, 7, '1770371009', 1, 1),
(39, 7, '1770371210', 1, 1),
(40, 7, '1770371504', 1, 1),
(41, 7, '1770371557', 1, 1),
(42, 7, '1770371771', 1, 1),
(43, 7, '1770372165', 1, 1),
(44, 7, '1770372172', 1, 1),
(45, 7, '1770372414', 1, 1),
(46, 7, '1770372690', 1, 1),
(47, 7, '1770372695', 1, 1),
(48, 7, '1770373387', 1, 1),
(49, 7, '1770374097', 1, 1),
(50, 7, '1770374343', 1, 1),
(51, 7, '1770374494', 1, 1),
(52, 7, '1770374855', 1, 1),
(53, 7, '1770374996', 1, 1),
(54, 14, '1771579965', 1, 1),
(55, 13, '1771579994', 1, 1),
(56, 11, '1771580137', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sale_detail`
--

CREATE TABLE `sale_detail` (
  `id` int(5) NOT NULL,
  `sale_id` int(5) NOT NULL,
  `stock_id` int(5) NOT NULL,
  `num` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `sale_detail`
--

INSERT INTO `sale_detail` (`id`, `sale_id`, `stock_id`, `num`, `status`) VALUES
(1, 1, 1, 1000, 1),
(2, 2, 2, 1000, 1),
(3, 3, 1, 100, 1),
(4, 4, 2, 100, 1),
(5, 5, 1, 100, 0),
(6, 5, 2, 100, 0),
(7, 6, 2, 1000, 1),
(8, 7, 2, 1000, 1),
(9, 8, 2, 100, 1),
(10, 9, 2, 1000, 1),
(11, 10, 2, 100, 1),
(12, 11, 9, 50, 1),
(13, 12, 1, 100, 1),
(14, 13, 1, 100, 1),
(15, 14, 1, 100, 1),
(16, 15, 11, 20, 1),
(17, 23, 1, 100, 1),
(18, 23, 2, 120, 1),
(19, 23, 3, 100, 1),
(20, 5, 1, 100, 0),
(21, 5, 2, 100, 0),
(22, 5, 1, 100, 0),
(23, 5, 2, 100, 0),
(24, 37, 1, 100, 1),
(25, 5, 1, 100, 0),
(26, 5, 2, 100, 0),
(27, 5, 1, 100, 0),
(28, 5, 2, 100, 0),
(29, 5, 1, 100, 0),
(30, 5, 2, 100, 0),
(31, 5, 1, 100, 0),
(32, 5, 2, 100, 0),
(33, 5, 1, 100, 0),
(34, 5, 2, 100, 0),
(35, 5, 1, 100, 0),
(36, 5, 2, 100, 0),
(37, 5, 1, 100, 0),
(38, 5, 2, 100, 0),
(39, 5, 1, 100, 0),
(40, 5, 2, 100, 0),
(41, 5, 1, 100, 0),
(42, 5, 2, 100, 0),
(43, 5, 1, 100, 0),
(44, 5, 2, 100, 0),
(45, 5, 1, 100, 0),
(46, 5, 2, 100, 0),
(47, 5, 1, 100, 0),
(48, 5, 2, 100, 0),
(49, 5, 1, 100, 0),
(50, 5, 2, 100, 0),
(51, 5, 1, 100, 0),
(52, 5, 2, 100, 0),
(53, 5, 1, 100, 0),
(54, 5, 2, 100, 0),
(55, 47, 1, 1, 1),
(56, 5, 1, 100, 0),
(57, 5, 2, 100, 0),
(58, 5, 1, 100, 0),
(59, 5, 2, 100, 0),
(60, 5, 1, 100, 0),
(61, 5, 2, 100, 0),
(62, 5, 1, 100, 0),
(63, 5, 2, 100, 0),
(64, 5, 9, 1000, 0),
(65, 48, 1, 100, 1),
(66, 48, 2, 100, 1),
(67, 48, 10, 100, 1),
(68, 5, 1, 100, 1),
(69, 5, 2, 100, 1),
(70, 5, 9, 1000, 1),
(71, 49, 1, 100, 1),
(72, 49, 2, 100, 1),
(73, 50, 1, 10, 1),
(74, 50, 2, 10, 1),
(75, 50, 11, 10, 1),
(76, 51, 1, 454, 1),
(77, 51, 2, 45587, 1),
(78, 51, 11, 5472, 1),
(79, 52, 1, 1000, 1),
(80, 53, 1, 1000, 1),
(81, 53, 2, 100, 1),
(82, 53, 3, 1000, 1),
(83, 53, 4, 100, 1),
(84, 54, 2, 1000, 1),
(85, 55, 1, 10, 1),
(86, 55, 2, 10, 1),
(87, 56, 1, 10, 1),
(88, 56, 2, 10, 1),
(89, 56, 3, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `buy` int(5) NOT NULL,
  `sale` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `name`, `buy`, `sale`, `status`) VALUES
(1, 'Product A', 10, 10, 1),
(2, 'Product B', 15, 20, 1),
(3, 'Product C', 20, 25, 1),
(4, 'Product D', 15, 30, 1),
(5, 'Product E', 25, 30, 1),
(6, 'Product F', 5, 20, 1),
(7, 'Product G', 10, 30, 1),
(8, 'Product H', 15, 25, 1),
(9, 'Product I', 5, 30, 1),
(10, 'Product J', 15, 35, 1),
(11, 'Product K', 15, 40, 1),
(12, 'Product L', 10, 40, 1),
(14, 'a', 10, 10, 1),
(15, 'sasa', 100, 2000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `name`, `status`) VALUES
(1, 'Sa', 1),
(2, 'Sb', 1),
(3, 'Sc', 1),
(4, 'Sd', 1),
(5, 'Se', 1),
(6, 'Sf', 1),
(7, 'Sg', 1),
(8, 'Sh', 1),
(9, 'a', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `login` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `u_type` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `login`, `name`, `pass`, `u_type`, `status`) VALUES
(1, 'admin', 'สน', '1234', 1, 1),
(2, 'test', 'test', '1234', 2, 1),
(3, 'dixka', 'dixxi', '4477', 2, 1),
(4, '', '', '', 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buy`
--
ALTER TABLE `buy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buy_detail`
--
ALTER TABLE `buy_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_detail`
--
ALTER TABLE `sale_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buy`
--
ALTER TABLE `buy`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `buy_detail`
--
ALTER TABLE `buy_detail`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=326;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sale`
--
ALTER TABLE `sale`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `sale_detail`
--
ALTER TABLE `sale_detail`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
