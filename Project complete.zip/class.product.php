<?php

class product
{

	function def()
	{
		?>
		<h2>Product Management</h2>
				 <button class='btn btn-primary' onclick='window.open("index.php?option=product&task=edit&id=0&ro=0","_self")'>
				 Add
			    </button>
				<input class="btn btn-success" type ="button" value ="Print" onclick="window.open('index.php?option=product&task=printed','_blank','toolbar=no,status=no,location=no,menubar=no')" />
		<table id='datatables' class='table table-bordered table-striped'>
			<thead>
				<tr>
					<th class='text-center'>
						ID
					</th>
					<th class='text-center'>
						Name
					</th>
					<th class='text-center'>
						Buy
					</th>
					<th class='text-center'>
						Sale
					</th>
					<th class='text-center'>
						Status
					</th>
					<th class='text-center'>
						Action
					</th>
				</tr>
			</thead>
			<tbody>
			<?php
				$conn = new connect();
				$sql = "select * from `product`";
				$res = $conn->query($sql);
				$a = 1;
				while ($cdr = $res->fetch())
				{
					echo "<tr>";
					echo "<td class='text-center'>";
					echo $a;
					echo "</td>";
					echo "<td>";
					echo $cdr['name'];
					echo "</td>";
					echo "<td>";
					echo $cdr['buy'];
					echo "</td>";
					echo "<td>";
					echo $cdr['sale'];
					echo "</td>";
					echo "<td class='text-center'>";
					if ($cdr['status'] == 1)
					{
						echo "Enable";
						$txt = "Disable";
						$bst = "btn-danger";
						$val = 0;
					}
					else
					{
						echo "Disable";
						$txt = "Enable";
						$bst = "btn-success";
						$val = 1;
					}
					echo "</td>";
					echo "<td class='text-center'>";
					echo "<button class='btn btn-warning' onclick='window.open(\"index.php?option=product&task=edit&id=".$cdr['id']."&ro=0\",\"_self\")'>";
					echo "Edit";
					echo "</button>";
					echo "<button class='btn btn-info' onclick='window.open(\"index.php?option=product&task=edit&id=".$cdr['id']."&ro=1\",\"_self\")'>";
					echo "Info";
					echo "</button>";
					echo "<button class='btn $bst' onclick='window.open(\"index.php?option=product&task=del&id=".$cdr['id']."&val=".$val."\",\"_self\")'>";
					echo $txt;
					echo "</button>";
					echo "</td>";
					echo "</tr>";
					$a++;
				}
			?>
			</tbody>
		</table>
		<?php
	}

	function del()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$val = $_REQUEST['val'];
		$sql = "update `product` set `status` = '".$val."' where `id` = '".$id."'";
		$res = $conn->query($sql);
		$conn->savelog($_SESSION['uid'],"En/Dis product",$sql);
		header("location:index.php?option=product&task=def");
	}

	function edit()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$ro = $_REQUEST['ro'];
		$rs = "";
		if ($id == 0)
		{
			$head = "Add";
			$name = "";
			$buy = "";
			$sale = "";
			
		}
		else
		{
			$head = "Edit";
			$sql = "select * from `product` where `id` = '".$id."'";
			$res = $conn->query($sql);
			while ($cdr = $res->fetch())
			{
				$name = $cdr['name'];
				$buy = $cdr['buy'];
				$sale = $cdr['sale'];
			}
		}
		if ($ro == 1)
		{
			$rs = "readonly='true'";
			$head = "Info";
		}
		?>
		<form action='index.php' method='post'>
		<table class='table table-bordered'>
			<tr>
				<td class='text-center' colspan='2'>
					<?php echo $head;?> product
				</td>
			</tr>
			<tr>
				<td>
					Name
				</td>
				<td>
					<input name='name' value='<?php echo $name;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td>
					Buy
				</td>
				<td>
					<input name='buy' value='<?php echo $buy;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td>
					Sale
				</td>
				<td>
					<input name='sale' value='<?php echo $sale;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td class='text-center' colspan='2'>
				<?php
					if($ro==0)
					{
					?>
					<input class='btn btn-success' type = 'submit' value='Save' />
					<?php
						}
					?>
					<input class='btn btn-secondary' type = 'button' value ='Back' onclick='window.open("index.php?option=product&task=def","_self")'/>
					<input type='hidden' name='option' value='product' />
					<input type='hidden' name='task' value='save' />
					<input type='hidden' name='id' value='<?php echo $id;?>' />
				</td>
			</tr>
		</table>
		</form>
		<?php
	}
		
		function save()
		{
			$conn = new connect();
			$id=$_REQUEST['id'];
			$name=$_REQUEST['name'];
			$buy=$_REQUEST['buy'];
			$sale=$_REQUEST['sale'];
			if($id==0)
			{
				$sql = "insert into`product` set `name` ='".$name."',`buy` ='".$buy."',`sale` ='".$sale."'";
			}
			else
			{
				$sql = "update `product` set `name` ='".$name."',`buy` ='".$buy."',`sale` ='".$sale."' where `id`='".$id."'";
			}
		$res = $conn->query($sql);
		$conn->savelog($_SESSION['uid'],"Save product",$sql);
		header("location:index.php?option=product&task=def");
	
		}

				 function printed()
 {
  $conn = new connect();
  $html = '
  <h2>Product</h2>
    <table border="1" cellpadding="5" cellspacing="0" style="width:100%;border-collapse:collapse,">
     <thead style="background-color:#f2f2f2;">
    <tr>
	<th align="center">
      ID
     </th>
	<th align="center">
      Name
     </th>
     <th align="center">
      Buy
     </th>    
     <th align="center">
      Sale
     </th>
	 <th align="center">
      Status
     </th>
    </tr>
   </thead>
   <tbody>';

  $sql = "select * from product";
    
   
  $res = $conn->query($sql);
  $a = 1;
  while ($cdr = $res->fetch())
  {
   $html = $html."<tr>";
   $html = $html.'<td align="center">';
   $html = $html.$a;
   $html = $html."</td>";
   $html = $html."<td>";
   $html = $html.$cdr['name'];
   $html = $html."</td>";
   $html = $html."<td>";
   $html = $html.$cdr['buy'];
   $html = $html."</td>";
   $html = $html."<td>";
   $html = $html.$cdr['sale'];
   $html = $html."</td>";
   $html = $html."<td>";
   $html = $html.$cdr['status'];
   $html = $html."</td>";
   $html = $html."</tr>";
   $a++;
  }
   $html=$html.'
   </tbody>
  </table>';
  $_SESSION['print_data']=$html;
  header('location:print.php');
 }
}

?>