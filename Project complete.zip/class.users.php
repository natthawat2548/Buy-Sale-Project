<?php

class users
{

	function def()
	{
		?>
		<h2>Users Management</h2>
				 <button class='btn btn-primary' onclick='window.open("index.php?option=users&task=edit&id=0&ro=0","_self")'>
				 Add
			    </button>
				<input class="btn btn-success" type ="button" value ="Print" onclick="window.open('index.php?option=users&task=printed','_blank','toolbar=no,status=no,location=no,menubar=no')" />
		<table id='datatables' class='table table-bordered table-striped'>
			<thead>
				<tr>
					<th class='text-center'>
						No.
					</th>
					<th class='text-center'>
						name
					</th>
					<th class='text-center'>
						buy
					</th>
					<th class='text-center'>
						sale
					</th>
					<th class='text-center'>
						Status
					</th>
					<th class='text-center'>
						Action
					</th>
				</tr>
			</thead>
			<tbody>
			<?php
				$conn = new connect();
				$sql = "select * from `users`";
				$res = $conn->query($sql);
				$a = 1;
				while ($cdr = $res->fetch())
				{
					echo "<tr>";
					echo "<td class='text-center'>";
					echo $a;
					echo "</td>";
					echo "<td>";
					echo $cdr['login'];
					echo "</td>";
					echo "<td>";
					echo $cdr['name'];
					echo "</td>";
					echo "<td class='text-center'>";
					if ($cdr['u_type'] == 1)
					{
						echo "Admin";
					}
					else
					{
						echo "Users";
					}
					echo "</td>";
					echo "<td class='text-center'>";
					if ($cdr['status'] == 1)
					{
						echo "Enable";
						$txt = "Disable";
						$bst = "btn-danger";
						$val = 0;
					}
					else
					{
						echo "Disable";
						$txt = "Enable";
						$bst = "btn-success";
						$val = 1;
					}
					echo "</td>";
					echo "<td class='text-center'>";
					echo "<button class='btn btn-warning' onclick='window.open(\"index.php?option=users&task=edit&id=".$cdr['id']."&ro=0\",\"_self\")'>";
					echo "Edit";
					echo "</button>";
					echo "<button class='btn btn-info' onclick='window.open(\"index.php?option=users&task=edit&id=".$cdr['id']."&ro=1\",\"_self\")'>";
					echo "Info";
					echo "</button>";
					echo "<button class='btn $bst' onclick='window.open(\"index.php?option=users&task=del&id=".$cdr['id']."&val=".$val."\",\"_self\")'>";
					echo $txt;
					echo "</button>";
					echo "</td>";
					echo "</tr>";
					$a++;
				}
			?>
			</tbody>
		</table>
		<?php
	}

	function del()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$val = $_REQUEST['val'];
		$sql = "update `users` set `status` = '".$val."' where `id` = '".$id."'";
		$res = $conn->query($sql);
		$conn->savelog($_SESSION['uid'],"En/Dis User",$sql);
		header("location:index.php?option=users&task=def");
	}

	function edit()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$ro = $_REQUEST['ro'];
		$rs = "";
		if ($id == 0)
		{
			$head = "Add";
			$login = "";
			$name = "";
			$pass = "";
			$u_type = 2;
		}
		else
		{
			$head = "Edit";
			$sql = "select * from `users` where `id` = '".$id."'";
			$res = $conn->query($sql);
			while ($cdr = $res->fetch())
			{
				$login = $cdr['login'];
				$name = $cdr['name'];
				$pass = $cdr['pass'];
				$u_type = $cdr['u_type'];
			}
		}
		if ($ro == 1)
		{
			$rs = "readonly='true'";
			$head = "Info";
		}
		?>
		<form action='index.php' method='post'>
		<table class='table table-bordered'>
			<tr>
				<td class='text-center' colspan='2'>
					<?php echo $head;?> User
				</td>
			</tr>
			<tr>
				<td>
					Login
				</td>
				<td>
					<input name='login' value='<?php echo $login;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td>
					Name
				</td>
				<td>
					<input name='name' value='<?php echo $name;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td>
					Password
				</td>
				<td>
					<input name='pass' value='<?php echo $pass;?>' <?php echo $rs;?> />
				</td>
			</tr>
			<tr>
				<td>
					User Type
				</td>
				<td>
				<?php
					if($u_type==1)
					{
						$r1 = "checked='checked'";
						$r2 = "";
					}
					else
					{
						$r1 = "";
						$r2 = "checked='checked'";
					}
				?>
					<input type='radio' name='u_type' value='1' <?php echo $r1." ".$rs;?> /> Admin
					<br />
					<input type='radio' name='u_type' value='2' <?php echo $r2." ".$rs;?> /> User
				</td>
			</tr>
			<tr>
				<td class='text-center' colspan='2'>
				<?php
					if($ro==0)
					{
					?>
					<input class='btn btn-success' type = 'submit' value='Save' />
					<?php
						}
					?>
					<input class='btn btn-secondary' type = 'button' value ='Back' onclick='window.open("index.php?option=users&task=def","_self")'/>
					<input type='hidden' name='option' value='users' />
					<input type='hidden' name='task' value='save' />
					<input type='hidden' name='id' value='<?php echo $id;?>' />
				</td>
			</tr>
		</table>
		</form>
		<?php
	}
		
		function save()
		{
			$conn = new connect();
			$id=$_REQUEST['id'];
			$login=$_REQUEST['login'];
			$name=$_REQUEST['name'];
			$pass=$_REQUEST['pass'];
			$u_type=$_REQUEST['u_type'];
			if($id==0)
			{
				$sql = "insert into`users` set `login` ='".$login."',`name` ='".$name."',`pass` ='".$pass."',`u_type` ='".$u_type."'";
			}
			else
			{
				$sql = "update `users` set `login` ='".$login."',`name` ='".$name."',`pass` ='".$pass."',`u_type` ='".$u_type."' where `id`='".$id."'";
			}
		$res = $conn->query($sql);
		$conn->savelog($_SESSION['uid'],"Save User",$sql);
		header("location:index.php?option=users&task=def");
	
		}
function printed()
{
 $conn = new connect();

 $html = '
 <h2>Users Management</h2>
 <table border="1" cellpadding="5" cellspacing="0" style="width:100%;border-collapse:collapse;">
  <thead style="background:#eee;">
   <tr>
    <th>No.</th>
    <th>Login</th>
    <th>Name</th>
    <th>User Type</th>
    <th>Status</th>
   </tr>
  </thead>
  <tbody>';

 $sql = "select * from users";
 $res = $conn->query($sql);

 $a = 1;
 while ($cdr = $res->fetch())
 {
  $type = ($cdr['u_type']==1) ? "Admin" : "User";
  $status = ($cdr['status']==1) ? "Enable" : "Disable";

  $html .= "<tr>";
  $html .= "<td align='center'>$a</td>";
  $html .= "<td>".$cdr['login']."</td>";
  $html .= "<td>".$cdr['name']."</td>";
  $html .= "<td align='center'>$type</td>";
  $html .= "<td align='center'>$status</td>";
  $html .= "</tr>";

  $a++;
 }

 $html .= "</tbody></table>";

 $_SESSION['print_data'] = $html;

 header("location:print.php");
}
}

?>