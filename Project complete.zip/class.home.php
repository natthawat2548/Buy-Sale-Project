 <?php
 
 class home
 {
 
	function def()
	{
		echo "Home";
	}

}

 ?>