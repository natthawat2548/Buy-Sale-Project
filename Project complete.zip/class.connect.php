 <?php
 
 class connect
 {
 
	function conn()
	 {
		$host = "localhost";
		$db = "phplab-2502";
		$user = "root";
		$pass = "";
		$conn = new PDO("mysql:host=$host;dbname=$db","$user","$pass");
		$conn->exec("set names utf8");
		return $conn;
	}

	function query($sql)
	 {
		$conn = $this->conn();
		$res = $conn->prepare($sql);
		$res->execute();
		return $res;
	}

	function query_getlastid($sql)
	{
		$conn = $this->conn();
		$res = $conn->prepare($sql);
		$res->execute();
		$res = $conn->lastInsertId();
		return $res;
	}
	
	 function savelog($uid, $action, $detail)
	 {
		$detail = str_replace("'","\'",$detail);
		$detail = str_replace('"','\"',$detail);
		$sql = "insert into`logs` set `action` ='".$action."',`detail` ='".$detail."',`uid` ='".$uid."' ,`dating` ='".time()."'";
		$res = $this->query($sql);
	 }


}

 ?>