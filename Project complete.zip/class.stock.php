<?php

class stock
{

 function def()
 {
  ?>
  <h2>Stock Management</h2>
     <button class='btn btn-primary' onclick='window.open("index.php?option=stock&task=edit&id=0&ro=0","_self")'>
     Add
       </button>
  <table id='datatables' class='table table-bordered table-striped'>
   <thead>
    <tr>
		<th class='text-center'>ID</th>
		<th class='text-center'>Name</th>
		<th class='text-center'>Buy</th>
		<th class='text-center'>Sale</th>
		<th class='text-center'>Status</th>
		<th class='text-center'>Action</th>
    </tr>
   </thead>
   <tbody>
   <?php
    $conn = new connect();
    $sql = "select * from `stock`";
    $res = $conn->query($sql);
    $a = 1;
    while ($cdr = $res->fetch())
    {
     echo "<tr>";
     echo "<td class='text-center'>".$a."</td>";
     echo "<td>".$cdr['name']."</td>";
     echo "<td>".$cdr['buy']."</td>";
     echo "<td>".$cdr['sale']."</td>";
     echo "<td class='text-center'>".$cdr['status']."</td>";
     echo "<td class='text-center'>";
     echo "<button class='btn btn-warning' onclick='window.open(\"index.php?option=stock&task=edit&id=".$cdr['id']."&ro=0\",\"_self\")'>Edit</button> ";
     echo "<button class='btn btn-info' onclick='window.open(\"index.php?option=stock&task=edit&id=".$cdr['id']."&ro=1\",\"_self\")'>Info</button> ";
     if ($cdr['status'] == 1)
     {
      $txt = "Disable";
      $bst = "btn-danger";
      $val = 0;
     }
     else
     {
      $txt = "Enable";
      $bst = "btn-success";
      $val = 1;
     }
     echo "<button class='btn $bst' onclick='window.open(\"index.php?option=stock&task=del&id=".$cdr['id']."&val=".$val."\",\"_self\")'>$txt</button>";
	  echo "<button class='btn btn-success' onclick='window.open(\"index.php?option=stock&task=upload_form&id=".$cdr['id']."&ro=0\",\"_self\")'>";
	  echo "Upload";
	  echo "</button> ";
     echo "</td>";
     echo "</tr>";
     $a++;
    }
   ?>
   </tbody>
  </table>
  <?php
 }
 function check()
 {
  ?>
  <h2>Stock Search Result</h2>
  
  <table class='table table-bordered table-striped'>
   <thead>
    <tr>
     <th class='text-center'>ID</th>
     <th class='text-center'>Name</th>
     <th class='text-center'>Buy</th>
     <th class='text-center'>Sale</th>
     <th class='text-center'>Status</th>
    </tr>
   </thead>
   <tbody>
  <?php
   $conn = new connect();
   $kw = $_REQUEST['keyword'];
   $sql = "select * from stock where name like '%".$kw."%'";
   $res = $conn->query($sql);
   $a = 1;
   while ($cdr = $res->fetch())
   {
    echo "<tr>";
    echo "<td class='text-center'>".$a."</td>";
    echo "<td>".$cdr['name']."</td>";
    echo "<td>".$cdr['buy']."</td>";
    echo "<td>".$cdr['sale']."</td>";
    echo "<td class='text-center'>".$cdr['status']."</td>";
    echo "</tr>";
    $a++;
   }
  ?>
   </tbody>
  </table>
  <center>
    <button class= 'btn btn-secondary' onclick='window.open("index.php?option=stock&task=checkstock","_self")'>Back</button>
  </center>
  <?php
 }

 function del()
 {
  $conn = new connect();
  $id = $_REQUEST['id'];
  $val = $_REQUEST['val'];
  $sql = "update stock set status = '".$val."' where id = '".$id."'";
  $res = $conn->query($sql);
  $conn->savelog($_SESSION['uid'],"En/Dis Stock",$sql);
  header("location:index.php?option=stock&task=def");
 }

 function edit()
 {
  $conn = new connect();
  $id = $_REQUEST['id'];
  $ro = $_REQUEST['ro'];
  $rs = "";
  if ($id == 0)
  {
   $head = "Add";
   $name = "";
   $buy = "";
   $sale = "";
  }
  else
  {
   $head = "Edit";
   $sql = "select * from stock where id = '".$id."'";
   $res = $conn->query($sql);
   while ($cdr = $res->fetch())
   {
    $name = $cdr['name'];
    $buy = $cdr['buy'];
    $sale = $cdr['sale'];
   }
  }
  if ($ro == 1)
  {
   $rs = "readonly='true'";
   $head = "Info";
  }
  ?>
  <form action='index.php' method='post'>
  <table class='table table-bordered'>
   <tr>
    <td class='text-center' colspan='2'>
     <?php echo $head;?> Stock
    </td>
   </tr>
   <tr>
    <td>Name</td>
    <td><input name='name' value='<?php echo $name;?>' <?php echo $rs;?> /></td>
   </tr>
   <tr>
    <td>Buy</td>
    <td><input name='buy' value='<?php echo $buy;?>' <?php echo $rs;?> /></td>
   </tr>
   <tr>
    <td>Sale</td>
    <td><input name='sale' value='<?php echo $sale;?>' <?php echo $rs;?> /></td>
   </tr>
   <tr>
    <td class='text-center' colspan='2'>
    <?php
     if($ro==0)
     {
    ?>
     <input class='btn btn-success' type='submit' value='Save' />
    <?php
     }
    ?>
     <input class='btn btn-secondary' type='button' value='Back' onclick='window.open("index.php?option=stock&task=def","_self")'/>
     <input type='hidden' name='option' value='stock' />
     <input type='hidden' name='task' value='save' />
     <input type='hidden' name='id' value='<?php echo $id;?>' />
    </td>
   </tr>
  </table>
  </form>
  <?php
 }

 function save()
 {
  $conn = new connect();
  $id=$_REQUEST['id'];
  $name=$_REQUEST['name'];
  $buy=$_REQUEST['buy'];
  $sale=$_REQUEST['sale'];
  if($id==0)
  {
   $sql = "insert into`stock` set name ='".$name."',`buy` ='".$buy."',`sale` ='".$sale."'";
  }
  else
  {
   $sql = "update stock set name ='".$name."',`buy` ='".$buy."',`sale` ='".$sale."' where `id`='".$id."'";
  }
  $res = $conn->query($sql);
  $conn->savelog($_SESSION['uid'],"Save Stock",$sql);
  header("location:index.php?option=stock&task=def");
 }
 function checkstock()
 {
  ?>
  <h2>Check Stock</h2>
   <button class='btn btn-primary' onclick='window.open("index.php?option=stock&task=printed","_blank","toolbar=no,status=no,menubar=no")'>
     Print
       </button>
</form>
  <table id = 'datatables' class='table table-bordered table-striped'>
   <thead>
    <tr>
     <th class='text-center'>
      No.
     </th>
	  <th class='text-center'>
      Image
     </th>
     <th class='text-center'>
      Name
     </th>
     <th class='text-center'>
      Buy
     </th>
     <th class='text-center'>
      Sale
     </th>
     <th class='text-center'>
      Profit
     </th>
     <th class='text-center'>
      Stock
     </th>
    </tr>
   </thead>
   <tbody>
   <?php
    $conn = new connect();
    $sql = "
    select
	`s`.`id` as id
     , `s`.`name` as name
     , `s`.`buy` as buy
     , `s`.`sale` as sale
     , ifnull((
      select
       sum(`buy_detail`.`num`)
      from
       `buy`, buy_detail
      where
       `buy`.`status` = '1'
       and `buy_detail`.`status` = '1'
       and `buy`.`id` = `buy_detail`.`buy_id`
       and `buy_detail`.`stock_id` = `s`.`id`
     ),0) as buyin
     , ifnull((
      select
       sum(`sale_detail`.`num`)
      from
       `sale`, sale_detail
      where
       `sale`.`status` = '1'
       and `sale_detail`.`status` = '1'
       and `sale`.`id` = `sale_detail`.`sale_id`
       and `sale_detail`.`stock_id` = `s`.`id`
     ),0) as saleout
    from 
     stock as s
    ";
    $res = $conn->query($sql);
    $a = 1;
    while ($cdr = $res->fetch())
    {
     echo "<tr>";
     echo "<td class='text-center'>";
     echo $a;
     echo "</td>";
     echo "<td>";
	 $file = str_pad($cdr['id'],3,0,STR_PAD_LEFT);
     echo "<img src = 'img/".$file."/".$file.".jpg' width = '100px'/>";
     echo "</td>";
	 echo "<td>";
     echo $cdr['name'];
     echo "</td>";
     echo "<td class='text-end'>";
     echo $cdr['buy'];
     echo "</td>";
     echo "<td class='text-end'>";
     echo $cdr['sale'];
     echo "</td>";
     echo "<td class='text-end'>";
     echo $cdr['sale'] - $cdr['buy'];
     echo "</td>";
     echo "<td class='text-center'>";
     echo $cdr['buyin'] - $cdr['saleout'];
     echo "</td>";
     echo "</tr>";
     $a++;
    }
   ?>
   </tbody>
  </table>
  <?php
 }
    function printed()
 {
  $conn = new connect();
  $html = '
  <h2>Check Stock</h2>
  <table border="1" cellpadding="5" cellspacing="0" style="width:100%;border-collapse:collapse,">
   <thead style="background-color:#f2f2f2;">
    <tr>
     <th align="center">
      No.
     </th>
     <th align="center">
      Name
     </th>
     <th align="center">
      Buy
     </th>
     <th align="center">
      Sale
     </th>
     <th align="center">
      Profit
     </th>
     <th align="center">
      Stock
     </th>
    </tr>
   </thead>
   <tbody>';
 
    $sql = "
    select
     `s`.`name` as name
     , `s`.`buy` as buy
     , `s`.`sale` as sale
     , ifnull((
      select
       sum(`buy_detail`.`num`)
      from
       `buy`, buy_detail
      where
       `buy`.`status` = '1'
       and `buy_detail`.`status` = '1'
       and `buy`.`id` = `buy_detail`.`buy_id`
       and `buy_detail`.`stock_id` = `s`.`id`
     ),0) as buyin
     , ifnull((
      select
       sum(`sale_detail`.`num`)
      from
       `sale`, sale_detail
      where
       `sale`.`status` = '1'
       and `sale_detail`.`status` = '1'
       and `sale`.`id` = `sale_detail`.`sale_id`
       and `sale_detail`.`stock_id` = `s`.`id`
     ),0) as saleout
    from 
     stock as s
    ";
    $res = $conn->query($sql);
    $a = 1;
    while ($cdr = $res->fetch())
    {
     $html=$html. "<tr>";
    $html=$html.'<td align="center">';
    $html=$html. $a;
     $html=$html."</td>";
    $html=$html. "<td>";
     $html=$html. $cdr['name'];
     $html=$html. "</td>";
     $html=$html. '<td align="center">';
     $html=$html.  $cdr['buy'];
      $html=$html.  "</td>";
      $html=$html.  '<td align="center">';
      $html=$html.  $cdr['sale'];
     $html=$html. "</td>";
     $html=$html. '<td align="center">';
     $html=$html. $cdr['sale'] - $cdr['buy'];
     $html=$html. "</td>";
     $html=$html. '<td align="center">';
     $html=$html. $cdr['buyin'] - $cdr['saleout'];
     $html=$html. "</td>";
     $html=$html. "</tr>";
     $a++;
    }
   $html=$html.'
   </tbody>
  </table>';
 $_SESSION['print_data']=$html;
 header('location:print.php');
}
function upload_form()
{
	$id = $_REQUEST['id'];
	?>
		<form action = 'index.php' method = 'post' enctype = "multipart/form-data">
		<table class = 'table table-bordered'>
			<tr>
				<td colspan = '2' class = 'text-center'>
					Upload Image
				</td>
			</tr>
			<tr>
				<td>
					Image
				</td>
				<td>
					<input type = 'file' name = 'file' accept = ".jpg"/>
				</td>
			</tr>
			<tr>
				<td colspan = '2' class = 'text-center'>
				<input  class = 'btn btn-success' type ='submit' value = 'Upload'/>
				<input  class = 'btn btn-secondary' type = 'button' value = 'back' onclick = 'window.open("index.php?option = stock&task = def","self")'/>
				<input type ='hidden' name = 'option' value = 'stock'/>
				<input type ='hidden' name = 'task' value = 'save_upload'/>
				<input type ='hidden' name = 'id' value = '<?php echo $id;?>'
				/>
				</td>
			</tr>
		</table>
		</form>
		<table class="table table-bordered table-striped">
			<thead>
				<tr>
					<td class = 'text-center'>
						No.
					</td>
					<td class = 'text-center'>
						Image
					</td>
					<td class = 'text-center'>
						Action
					</td>
				</tr>
			</thead>
			<tbody>
				<?php
					$a = 1;
					$file =str_pad($id,3,0,STR_PAD_LEFT);
					$dir = "img/".$file."/";
					$imgs = glob($dir."*.{jpg,jpeg}",GLOB_BRACE | GLOB_ERR);
					foreach ($imgs as $img)
					{
						echo "<tr>";
						echo "<td class = 'text-center'>";
						echo $a;
						echo "</td>";
						echo "<td class = 'text-center'>";
						echo "<img src = '".$img."' width = '100px';>";
						echo "</td>";
						echo "<td class = 'text-center'>";
						echo "<input type ='button' class= 'btn btn-danger' value = 'Delete' onclick = 'window.open(\"index.php?option=stock&task=del_file&id=".$id."&file=".basename($img)."\",\"_self\")'>";
						echo "</td>";
						echo"</tr>";
					}
					

				?>
			</tbody>
		</table>
		<?php
}
	function save_upload()
	{
		$id = $_REQUEST['id'];
		$file =str_pad($id,3,0,STR_PAD_LEFT);
		$dir = "img/".$file;
		if(is_dir($dir)==FALSE)
		{
			mkdir($dir,0777,true);
		}
		$file_name = $dir."/".$file.".jpg";
		move_uploaded_file($_FILES["file"]["tmp_name"],$file_name);
		header("location:index.php?option=stock&task=def");
	}

	function del_file()
	{
		$id = $_REQUEST['id'];
		$file =str_pad($id,3,0,STR_PAD_LEFT);
		$dir = "img/".$file;
		$file_name = $dir."/".$file.".jpg";
		unlink($file_name);
		header("location:index.php?option=stock&task=def");
	}
		


}

?>