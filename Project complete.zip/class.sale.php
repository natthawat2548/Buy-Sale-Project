<?php

class sale
{
		function def()
		{
		?>
		<h2>Sale Management</h2>
				 <button class='btn btn-primary' onclick='window.open("index.php?option=sale&task=edit&id=0&ro=0","_self")'>
				 Add
			    </button></button> <input class="btn btn-success" type ="button" value ="Print" onclick="window.open('index.php?option=sale&task=printed','_blank','toolbar=no,status=no,location=no,menubar=no')" />
			<button class='btn btn-info' onclick="window.open('index.php?option=sale&task=print_last','_blank')">
			Print Last Order
			</button>
		<table id ='datatables' class='table table-bordered table-striped'>
			<thead>
				<tr>
					<th class='text-center'>
						No.
					</th>
					<th class='text-center'>
						Date
					</th>				
					<th class='text-center'>
						customer 
					</th>
					<th class='text-center'>
						User
					</th>
					<th class='text-center'>
						Cost
					</th>
					<th class='text-center'>
						Status
					</th>
					<th class='text-center'>
						Action
					</th>
				</tr>
			</thead>
			<tbody>
			<?php
				$conn = new connect();
				$sql = "
				select 
					`sale`.`id` as `id` 
					,`sale`.`dating` as `dating`
					,`customer`.`name` as `sname`
					,`users`.`login` as `uname`
					,`sale`.`status` as `status`
					,ifnull((
						select 
							sum(`sale_detail`.`num` * `stock`.`sale`)
						from		
							`sale_detail` ,`stock`
						where
							`sale_detail`.`status` > 0 
							and `sale_detail`.`sale_id`= `sale`.`id`
							and `sale_detail`.`stock_id`= `stock`.`id`
					),0) as `cost`
				from 
					`sale`, `customer`,`users`
				where
					`sale`.`customer_id` = `customer`.`id`
					and `sale`.`uid` = `users`.`id`
				";
				$res = $conn->query($sql);
				$a = 1;
				while ($cdr = $res->fetch())
				{
					echo "<tr>";
					echo "<td class='text-center'>";
					echo $a;
					echo "</td>";
					echo "<td class='text-center'>";
					echo date('d/m/Y H:i:s' ,$cdr['dating']);
					echo "</td>";
					echo "<td class='text-center'>";
					echo $cdr['sname'];
					echo "</td>";
					echo "<td class='text-center'>";
					echo $cdr['uname'];
					echo "</td>";
					echo "<td class='text-end'>";
					echo $cdr['cost'];
					echo "</td>";
					echo "<td class='text-center'>";
					if ($cdr['status'] == 1)
					{
						echo "Enable";
						$txt = "Disable";
						$bst = "btn-danger";
						$val = 0;
					}
					else
					{
						echo "Disable";
						$txt = "Enable";
						$bst = "btn-success";
						$val = 1;
					}
					echo "</td>";
					echo "<td class='text-center'>";
					echo "<button class='btn btn-warning' onclick='window.open(\"index.php?option=sale&task=edit&id=".$cdr['id']."&ro=0\",\"_self\")'>";
					echo "Edit";
					echo "</button>";
					echo "<button class='btn btn-info' onclick='window.open(\"index.php?option=sale&task=edit&id=".$cdr['id']."&ro=1\",\"_self\")'>";
					echo "Info";
					echo "</button>";
					echo "<button class='btn $bst' onclick='window.open(\"index.php?option=sale&task=del&id=".$cdr['id']."&val=".$val."\",\"_self\")'>";
					echo $txt;
					echo "</button>";
					echo "</td>";
					echo "</tr>";
					$a++;
				}
			?>
			</tbody>
		</table>
		<?php
		}


	function edit()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$ro = $_REQUEST['ro'];
		if($id ==0)
		{
			$sql ="select max(`id`) as `docid` from `sale`";
			$res = $conn->query($sql);
			while ($cdr = $res->fetch())
			{
				$docid = $cdr['docid'] + 1;
			}
			$dating = time();
			$customer_id =0;
		}
		else
		{
			$sql = "select * from `sale` where `id` = '".$id."'";
			$res = $conn->query($sql);
			while ($cdr = $res->fetch())
			{
				$docid = $cdr['id'];
				$dating = $cdr['dating'];
				$customer_id = $cdr['customer_id'];
			}
		}
		?>
		<form action="index.php" method="post">
		<table class="table table-bordered">
			<tr>
				<td class='text-center' colspan='2'>
					Sale Order
				</td>
			</tr>
			<tr>
				<td>
					Document ID
				</td>
				<td>
					<?php echo $docid;?>
				</td>
			</tr>
			<tr>
				<td>
					Date
				</td>
				<td>
					<?php echo date('d/m/Y H:i:s',$dating);?>
				</td>
			</tr>
			<tr>
				<td>
					Customer
				</td>
				<td>
					<select name ='customer_id'>
					<?php 
						$sql = "select * from `customer` where `status` > 0";
						$res = $conn->query($sql);
						while($cdr = $res->fetch())
						{
							$ch="";
							if ($cdr['id'] == $customer_id)
							{
								$ch = "checked='check'";
							}
							echo "<option value='".$cdr['id']."' ".$ch.">";
							echo $cdr['name'];
							echo "</option>";
						}
					?>
					</select>
				</td>
			</tr>
			<tr>
				<td class='text-center' colspan='2'>
				<?php
					if ($ro == 0) 
					{
					?>
					<input class="btn btn-success" type ="submit" value ="Save">
					<?php
					}
					else
					{
					?>
					<input class="btn btn-success" type ="button" value ="Print" onclick="window.open('index.php?option=sale&task=printed_detail&id=<?php echo $id;?>','_blank','toolbar=no,status=no,location=no,menubar=no')" />
					<?php
					}
					?>
					<input type="button" class="btn btn-secondary" value="Back" onclick="window.open('index.php?option=sale&task=def','_self')"/>
					<input type ="hidden" name="option" value="sale" />
					<input type ="hidden" name="task" value="save" />
					<input type ="hidden" name="id" value="<?php echo $id;?>" />
				</td>
			</tr>
		</table>
		<hr />
		<table class='table table-bordered table-striped'>
			<thead>
				<tr>
					<th class='text-center'>
						ID
					</th>
					<th class='text-center'>
						Name
					</th>
					<th class='text-center'>
						sale
					</th>
					<th class='text-center'>
						Number
					</th>
					<th class='text-center'>
						In Stock
					</th>
				</tr>
			</thead>
			<tbody>
			<?php
				$conn = new connect();
				$sql = "
				select 
					`stock`.`id`as `id`
					, `stock`.`name`as `name`
					, `stock`.`sale`as `sale`
					, ifnull((
					select 
						`sale_detail`.`num`
					from
						`sale_detail`
					where
					`sale_detail`.`status`>0
					and `sale_detail`.`sale_id`= '".$id."'
					and `sale_detail`.`stock_id`= `stock`.`id`
					),0) as `num`
					
					
					
					, ifnull((
					select
						sum(`buy_detail`.`num`)
					from
						`buy`,`buy_detail`
					where
						`buy`.`status` > 0
						and `buy_detail`.`status` > 0
						and `buy`.`id` = `buy_detail`.`buy_id`
						and `buy_detail`.`stock_id` = `stock`.`id`
						and `buy_detail`.`buy_id` <> '".$id."'
					),0) as `sto`
					
					
					, ifnull((
					select
						sum(`sale_detail`.`num`)
					from
						`sale`,`sale_detail`
					where
						`sale`.`status` > 0
						and `sale_detail`.`status` > 0
						and `sale`.`id` = `sale_detail`.`sale_id`
						and `sale_detail`.`stock_id` = `stock`.`id`
						and `sale_detail`.`sale_id` <> '".$id."'
					),0) as `stu`
				from 
					`stock`
				where 
					`stock`.`status`>0
				";
				$res = $conn->query($sql);
				$a = 1;
				while ($cdr = $res->fetch())
				{
					echo "<tr>";
					echo "<td class='text-center'>";
					echo $a;
					echo "</td>";
					echo "<td>";
					echo $cdr['name'];
					echo "</td>";
					echo "<td class ='text-end'>";
					echo $cdr['sale'];
					echo "</td>";
					echo "<td>";
					echo "<input type='number' name='an-".$a."' value='".$cdr['num']."' />";
					echo "<input type='hidden' name='ap-".$a."' value='".$cdr['id']."' />";
					echo "</td>";
					echo "<td  class ='text-end'>";
					echo $cdr['sto']-$cdr['stu'];
					echo "</td>";
					echo "</tr>";
					$a++;
				}
			?>
			</tbody>
		</table>
		<input type='hidden' name='limit' value='<?php echo $a;?>' />
		</form>
		<?php
	}

		function save()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$customer_id = $_REQUEST['customer_id'];	
		$limit = $_REQUEST['limit'];
		if($id == 0)
		{
			$sql = "insert into `sale` set `customer_id` = '".$customer_id."', `dating` ='".time()."', `uid` = '".$_SESSION['uid']."'";
			$sale_id = $conn->query_getlastid($sql);
		}
		else
		{		
			$sql = "update `sale` set `customer_id` = '".$customer_id."', `dating` ='".time()."', `uid` = '".$_SESSION['uid']."'where `id` = '".$id."'";
			$res = $conn->query($sql);
			$sale_id = $id;		
		}
		$conn->savelog($_SESSION['uid'],"Save sale",$sql);
		$sql = "update `sale_detail` set `status` = 0 where `sale_id`='".$sale_id."'";
		$res = $conn->query($sql);
		$a = 1;
		while ($a < $limit)
		{
			if($_REQUEST['an-'.$a] >0)
			{
				$sql = "insert into `sale_detail` set `sale_id` = '".$sale_id."', `stock_id` = '".$_REQUEST['ap-'.$a]."' , `num` = '".$_REQUEST['an-'.$a]."'" ;
				$res = $conn->query($sql);
			}
			$a++; 
		}
		function save()
{
    echo "<script>";
    echo "window.open('index.php?option=sale&task=printed_detail&id=".$sale_id."', '_blank');";
    echo "window.location.href = 'index.php?option=sale&task=def';";
    echo "</script>";
    exit;
}
		header("location:index.php?option=sale&task=def");
	}

	function del()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$val = $_REQUEST['val'];
		$sql = "update `sale` set `status` = '".$val."' where `id` = '".$id."'";
		$res = $conn->query($sql);
		$conn->savelog($_SESSION['uid'],"En/Dis sale",$sql);
		header("location:index.php?option=sale&task=def");
	}
	function printed_detail()
	{
		$conn = new connect();
		$id = $_REQUEST['id'];
		$sql = "select * from `sale` where `id` = '".$id."'";
		$res = $conn->query($sql);
		while ($cdr = $res->fetch())
		{
			$docid = $cdr['id'];
			$dating = $cdr['dating'];
			$customer_id = $cdr['customer_id'];
		}
		$html = '
		  <table border="1" cellpadding="5" cellspacing="0" style="width:100%;border-collapse:collapse,">
						<tr>
				<td align = "center" colspan="2" style="background-color: #D3D3D3;">
					<b>Sale Order</b>
				</td>
			</tr>
			<tr>
				<td>
					<b>Document ID</b>
				</td>
					<td>'.$docid.'
				</td>
			</tr>
			<tr>
				<td>
					<b>Date</b>
				</td>
				<td>
					'.date('d/m/Y H:i:s',$dating).'
				</td>
			</tr>
			<tr>
				<td>
					<b>Customer</b>
				</td>
				<td>';
				$sql = "select * from `customer` where `id` = '".$customer_id."'";
				$res = $conn->query($sql);
				$cdr = $res->fetch();
				$html = $html.$cdr['name'].'
				</td>
			</tr>
		</table>
		<br />
		<hr />
		<br />
		   <table border="1" cellpadding="5" cellspacing="0" style="width:100%;border-collapse:collapse,">
		   <thead style="background-color:#f2f2f2;">
				<tr style="background-color: #D3D3D3;">
					<th align="center">
						<b>ID</b>
					</th>
					<th align="center">
						<b>Name</b>
					</th>				
					<th align="center">
						<b>Sale</b>
					</th>
					<th align="center">
						<b>Number</b>
					</th>
					<th align="center">
						<b>Instock</b>
					</th>
				</tr>
			</thead>
			<tbody>';
				$sql = "
				select 
					`stock`.`id`as `id`
					, `stock`.`name`as `name`
					, `stock`.`sale`as `sale`
					, ifnull((
					select 
						`sale_detail`.`num`
					from
						`sale_detail`
					where
					`sale_detail`.`status`>0
					and `sale_detail`.`sale_id`= '".$id."'
					and `sale_detail`.`stock_id`= `stock`.`id`
					),0) as `num`
					
					
					
					, ifnull((
					select
						sum(`buy_detail`.`num`)
					from
						`buy`,`buy_detail`
					where
						`buy`.`status` > 0
						and `buy_detail`.`status` > 0
						and `buy`.`id` = `buy_detail`.`buy_id`
						and `buy_detail`.`stock_id` = `stock`.`id`
						and `buy_detail`.`buy_id` <> '".$id."'
					),0) as `sto`
					
					
					, ifnull((
					select
						sum(`sale_detail`.`num`)
					from
						`sale`,`sale_detail`
					where
						`sale`.`status` > 0
						and `sale_detail`.`status` > 0
						and `sale`.`id` = `sale_detail`.`sale_id`
						and `sale_detail`.`stock_id` = `stock`.`id`
						and `sale_detail`.`sale_id` <> '".$id."'
					),0) as `stu`
				from 
					`stock`
				where 
					`stock`.`status`>0
				having `num`> 0
				";
				$res = $conn->query($sql);
				$a = 1;
				$tt = 0;
				while ($cdr = $res->fetch())
				{
					$html = $html."<tr>";
					$html = $html.'<td align="center">';
					$html = $html.$a;
					$html = $html."</td>";
					$html = $html."<td>";
					$html = $html.$cdr['name'];
					$html = $html."</td>";
					$html = $html.'<td align="right">';
					$html = $html.number_format($cdr['sale'],2);
					$html = $html."</td>";
					$html = $html.'<td align="right">';
					$html = $html.number_format($cdr['num']);
					$html = $html."</td>";
					$instock = $cdr['sto'] - $cdr['stu'];
					$html = $html.'<td align="right">';
					$html = $html.number_format($instock);
					$tt = $tt + $instock;
					$html = $html."</td>";
					$html = $html."</tr>";
					$a++;
				}
				$html = $html."<tr>";
				$html = $html.'<td align="right" colspan="4" style="background-color: #D3D3D3;">';
				$html = $html."<b>";
				$html = $html."Total";
				$html = $html."</b>";
				$html = $html."</td>";
				$html = $html.'<td align="right" style="background-color: #D3D3D3;">';
				$html = $html."<b>";
				$html = $html.number_format($tt,2);
				$html = $html."</b>";
				$html = $html."</td>";
				$html = $html."</tr>";
		   $html=$html.'
		   </tbody>
		  </table>';
			$_SESSION['print_data']=$html;
			header('location:print.php');
		}
	
		function printed()
		{
			$conn = new connect();
				$html = '
		<h2>Sale Management</h2>
		  <table border="1" cellpadding="5" cellspacing="0" style="width:100%;border-collapse:collapse,">
		   <thead style="background-color:#f2f2f2;">
				<tr style="background-color: #D3D3D3;">
					<th align="center">
						<b>No.</b>
					</th>
					<th align="center">
						<b>Date</b>
					</th>				
					<th align="center">
						<b>Customer</b>
					</th>
					<th align="center">
						<b>User</b>
					</th>
					<th align="center">
						<b>Cost</b>
					</th>
				</tr>
			</thead>
			<tbody>';
				$sql =  "
				select 
					`sale`.`id` as `id` 
					,`sale`.`dating` as `dating`
					,`customer`.`name` as `sname`
					,`users`.`login` as `uname`
					,`sale`.`status` as `status`
					,ifnull((
						select 
							sum(`sale_detail`.`num` * `stock`.`sale`)
						from		
							`sale_detail` ,`stock`
						where
							`sale_detail`.`status` > 0 
							and `sale_detail`.`sale_id`= `sale`.`id`
							and `sale_detail`.`stock_id`= `stock`.`id`
					),0) as `cost`
				from 
					`sale`, `customer`,`users`
				where
					`sale`.`customer_id` = `customer`.`id`
					and `sale`.`uid` = `users`.`id`
				";
				$res = $conn->query($sql);
				$a = 1;
				$tt = 0;
				while ($cdr = $res->fetch())
				{
					$html = $html."<tr>";
					$html = $html.'<td align="center">';
					$html = $html.$a;
					$html = $html."</td>";
					$html = $html.'<td align="center">';
					$html = $html.date('d/m/Y H:i:s' ,$cdr['dating']);
					$html = $html."</td>";
					$html = $html.'<td align="center">';
					$html = $html.$cdr['sname'];
					$html = $html."</td>";
					$html = $html.'<td align="center">';
					$html = $html.$cdr['uname'];
					$html = $html."</td>";
					$html = $html.'<td align="right">';
					$html = $html.number_format($cdr['cost'],2);
					$tt = $tt + $cdr['cost'];
					$html = $html."</td>";
					$html = $html."</tr>";
					$a++;
				}
				$html = $html."<tr>";
				$html = $html.'<td align="right" colspan="4" style="background-color: #D3D3D3;">';
				$html = $html."<b>";
				$html = $html."Total";
				$html = $html."</b>";
				$html = $html."</td>";
				$html = $html.'<td align="right" style="background-color: #D3D3D3;">';
				$html = $html."<b>";
				$html = $html.number_format($tt,2);
				$html = $html."</b>";
				$html = $html."</td>";
				$html = $html."</tr>";
		   $html=$html.'
		   </tbody>
		  </table>';
			$_SESSION['print_data']=$html;
			header('location:print.php');
		}

function print_last()
{
    $conn = new connect();
    $sql = "select `id` from `sale` order by `id` desc limit 1";
    $res = $conn->query($sql);
    $cdr = $res->fetch();
    $last_id = $cdr['id'];

    $_REQUEST['id'] = $last_id;
    $this->printed_detail(); 
}

}

?> 
