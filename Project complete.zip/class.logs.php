 <?php
 
 class logs
 {
 
	 function def()
	 {
		 $conn = new connect();
		?>
		<h2>Logs Data</h2>
		<input class="btn btn-success" type ="button" value ="Print" onclick="window.open('index.php?option=logs&task=printed','_blank','toolbar=no,status=no,location=no,menubar=no')" />
		<table id = 'datatables' class='table table-bordered table-striped'>
			<thead>
				<tr>
					<th class='text-center'>
						No.
					</th>
					<th class='text-center'>
						Date
					</th>
					<th class='text-center'>
						User
					</th>
					<th class='text-center'>
						Action
					</th>
				</tr>
			</thead>
			<tbody>
			<?php
			$sql ="select * from `logs` left join `users`on `users`.`id`=`logs`.`uid`";
			$res = $conn->query($sql);
			$a =1;
			while ($cdr = $res->fetch())
			{
				echo "<tr>";
				echo "<td class='text-center'>";
				echo $a;
				echo "</td>";
				echo "<td class='text-center'>";
				echo date('d/m/Y H:i:s',$cdr['dating']);
				echo "</td>";
				echo "<td class='text-center'>";
				echo $cdr['login'];
				echo "</td>";
				echo "<td class='text-center'>";
				echo $cdr['action'];
				echo "</td>";
				echo "</tr>";
				$a++;
			}
		?>
			</tbody>
		</table>
		<?php
	 }

	 function login_form()
	 {
		 $al = 0;
		 if (isset($_REQUEST['a']))
		 {
			$al =1;
		 }
		 ?>
		<form action='index.php' method='post'>
		<table class='table table-bordered'>
		<tr>
			<td class='text-center' colspan='2'>
				Log in
			</td>
		</tr>
		<tr>
			<td>
				Username
			</td>
			<td>
				<input name='user'/>
			</td>
		</tr>
		<tr>
			<td>
				Password
			</td>
			<td>
				<input name='pass' type='password'/>
			</td>
		</tr>
		<tr>
			<td class='text-center' colspan='2'>
				<input type ='submit' value='Login' />
				<input type ='hidden' name='option' value='logs' />
				<input type ='hidden' name='task' value='Login' />
				<?php
			 		if ($al == 1)
					{
			 			echo "<br />";
			 			echo "<span class='text-danger'>";
						echo "Username and/or Password are incorrect";
						echo "</span>"; 
					}
			 ?>
			</td>
		</tr>
		</table>
		</form>
		<?php
	 }

	 function login()
	 {
		$conn = new connect();
		$user = $_REQUEST['user'];
		$pass = $_REQUEST['pass'];
		echo $user." : ".$pass;
		$sql = "select * from `users`where`login`= '".$user."' and `pass`= '".$pass."'";
		$res = $conn->query($sql);
		$uid = 0;
		while ($cdr = $res->fetch())
		{
			$uid = $cdr['id'];
			$_SESSION['uid'] = $uid;
			$_SESSION['name'] = $cdr['name'];
		}
		if($uid == 0)
		{
			$conn->savelog($_SESSION['uid'],"Log in","Login error");
			header("location:index.php?option=logs&task=login_form&a=1");
		}
		else
		{
			$conn->savelog($_SESSION['uid'],"Log in","Login pass");
			header("location:index.php?option=stock&task=def");
		}
	 }

	function logout()
	 {
		$conn = new connect();
		$conn->savelog($_SESSION['uid'],"Log out","Log out");
		session_destroy();
		header("location:index.php");
	}
	
	 function printed()
 {
			$conn = new connect();
			$html  = '
	<h2>Logs</h2>
	<table border="1" cellpadding="5" cellspancing="0" style="width:100%; border-collapse: collapse;">
		<thead style="background-color: #f2f2f2;">
			<tr>
				<th align="center">
					 No.
				</th>
				 <th align="center">
					Date
				</th>
				<th align="center">
					 User
				</th>
				<th align="center">
					Action
				</th>
			</tr>
		</thead>
		<tbody>';
			 $sql = "select 
			 `users`.`login` as `users.login`
			  ,`logs`.`action` as `logs.action`
			 from `logs`,`users`";
    $res = $conn->query($sql);
    $a = 1;
    while ($cdr = $res->fetch())
  {
   $html .= "<tr>";
   $html .= "<td align='center'>$a</td>";
   $html .= "<td align='center'>".date('d/m/Y H:i:s', $cdr['dating'])."</td>";
   $html .= "<td align='center'>".$cdr['users.login']."</td>";
   $html .= "<td align='center'>".$cdr['logs.action']."</td>";
   $html .= "</tr>";
   $a++;
  }
   
   $html = $html.'
   </tbody>
  </table>';
  $_SESSION['print_data'] = $html;
  header('location:print.php');
  
 }

}

 ?>